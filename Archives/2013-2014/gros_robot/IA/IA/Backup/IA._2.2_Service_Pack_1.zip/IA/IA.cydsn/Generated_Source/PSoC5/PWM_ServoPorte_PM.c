/*******************************************************************************
* File Name: PWM_ServoPorte_PM.c
* Version 2.40
*
* Description:
*  This file provides the power management source code to API for the
*  PWM.
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/
#include "cytypes.h"
#include "PWM_ServoPorte.h"

static PWM_ServoPorte_backupStruct PWM_ServoPorte_backup;


/*******************************************************************************
* Function Name: PWM_ServoPorte_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration of the component.
*  
* Parameters:  
*  None
*
* Return: 
*  None
*
* Global variables:
*  PWM_ServoPorte_backup:  Variables of this global structure are modified to 
*  store the values of non retention configuration registers when Sleep() API is 
*  called.
*
*******************************************************************************/
void PWM_ServoPorte_SaveConfig(void) 
{
    
    #if(!PWM_ServoPorte_UsingFixedFunction)
        #if (CY_UDB_V0)
            PWM_ServoPorte_backup.PWMUdb = PWM_ServoPorte_ReadCounter();
            PWM_ServoPorte_backup.PWMPeriod = PWM_ServoPorte_ReadPeriod();
            #if (PWM_ServoPorte_UseStatus)
                PWM_ServoPorte_backup.InterruptMaskValue = PWM_ServoPorte_STATUS_MASK;
            #endif /* (PWM_ServoPorte_UseStatus) */
            
            #if(PWM_ServoPorte_UseOneCompareMode)
                PWM_ServoPorte_backup.PWMCompareValue = PWM_ServoPorte_ReadCompare();
            #else
                PWM_ServoPorte_backup.PWMCompareValue1 = PWM_ServoPorte_ReadCompare1();
                PWM_ServoPorte_backup.PWMCompareValue2 = PWM_ServoPorte_ReadCompare2();
            #endif /* (PWM_ServoPorte_UseOneCompareMode) */
            
           #if(PWM_ServoPorte_DeadBandUsed)
                PWM_ServoPorte_backup.PWMdeadBandValue = PWM_ServoPorte_ReadDeadTime();
            #endif /* (PWM_ServoPorte_DeadBandUsed) */
          
            #if ( PWM_ServoPorte_KillModeMinTime)
                PWM_ServoPorte_backup.PWMKillCounterPeriod = PWM_ServoPorte_ReadKillTime();
            #endif /* ( PWM_ServoPorte_KillModeMinTime) */
        #endif /* (CY_UDB_V0) */
        
        #if (CY_UDB_V1)
            #if(!PWM_ServoPorte_PWMModeIsCenterAligned)
                PWM_ServoPorte_backup.PWMPeriod = PWM_ServoPorte_ReadPeriod();
            #endif /* (!PWM_ServoPorte_PWMModeIsCenterAligned) */
            PWM_ServoPorte_backup.PWMUdb = PWM_ServoPorte_ReadCounter();
            #if (PWM_ServoPorte_UseStatus)
                PWM_ServoPorte_backup.InterruptMaskValue = PWM_ServoPorte_STATUS_MASK;
            #endif /* (PWM_ServoPorte_UseStatus) */
            
            #if(PWM_ServoPorte_DeadBandMode == PWM_ServoPorte__B_PWM__DBM_256_CLOCKS || \
                PWM_ServoPorte_DeadBandMode == PWM_ServoPorte__B_PWM__DBM_2_4_CLOCKS)
                PWM_ServoPorte_backup.PWMdeadBandValue = PWM_ServoPorte_ReadDeadTime();
            #endif /*  deadband count is either 2-4 clocks or 256 clocks */
            
            #if(PWM_ServoPorte_KillModeMinTime)
                 PWM_ServoPorte_backup.PWMKillCounterPeriod = PWM_ServoPorte_ReadKillTime();
            #endif /* (PWM_ServoPorte_KillModeMinTime) */
        #endif /* (CY_UDB_V1) */
        
        #if(PWM_ServoPorte_UseControl)
            PWM_ServoPorte_backup.PWMControlRegister = PWM_ServoPorte_ReadControlRegister();
        #endif /* (PWM_ServoPorte_UseControl) */
    #endif  /* (!PWM_ServoPorte_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: PWM_ServoPorte_RestoreConfig
********************************************************************************
* 
* Summary:
*  Restores the current user configuration of the component.
*
* Parameters:  
*  None
*
* Return: 
*  None
*
* Global variables:
*  PWM_ServoPorte_backup:  Variables of this global structure are used to  
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void PWM_ServoPorte_RestoreConfig(void) 
{
        #if(!PWM_ServoPorte_UsingFixedFunction)
            #if (CY_UDB_V0)
                /* Interrupt State Backup for Critical Region*/
                uint8 PWM_ServoPorte_interruptState;
                /* Enter Critical Region*/
                PWM_ServoPorte_interruptState = CyEnterCriticalSection();
                #if (PWM_ServoPorte_UseStatus)
                    /* Use the interrupt output of the status register for IRQ output */
                    PWM_ServoPorte_STATUS_AUX_CTRL |= PWM_ServoPorte_STATUS_ACTL_INT_EN_MASK;
                    
                    PWM_ServoPorte_STATUS_MASK = PWM_ServoPorte_backup.InterruptMaskValue;
                #endif /* (PWM_ServoPorte_UseStatus) */
                
                #if (PWM_ServoPorte_Resolution == 8)
                    /* Set FIFO 0 to 1 byte register for period*/
                    PWM_ServoPorte_AUX_CONTROLDP0 |= (PWM_ServoPorte_AUX_CTRL_FIFO0_CLR);
                #else /* (PWM_ServoPorte_Resolution == 16)*/
                    /* Set FIFO 0 to 1 byte register for period */
                    PWM_ServoPorte_AUX_CONTROLDP0 |= (PWM_ServoPorte_AUX_CTRL_FIFO0_CLR);
                    PWM_ServoPorte_AUX_CONTROLDP1 |= (PWM_ServoPorte_AUX_CTRL_FIFO0_CLR);
                #endif /* (PWM_ServoPorte_Resolution == 8) */
                /* Exit Critical Region*/
                CyExitCriticalSection(PWM_ServoPorte_interruptState);
                
                PWM_ServoPorte_WriteCounter(PWM_ServoPorte_backup.PWMUdb);
                PWM_ServoPorte_WritePeriod(PWM_ServoPorte_backup.PWMPeriod);
                
                #if(PWM_ServoPorte_UseOneCompareMode)
                    PWM_ServoPorte_WriteCompare(PWM_ServoPorte_backup.PWMCompareValue);
                #else
                    PWM_ServoPorte_WriteCompare1(PWM_ServoPorte_backup.PWMCompareValue1);
                    PWM_ServoPorte_WriteCompare2(PWM_ServoPorte_backup.PWMCompareValue2);
                #endif /* (PWM_ServoPorte_UseOneCompareMode) */
                
               #if(PWM_ServoPorte_DeadBandMode == PWM_ServoPorte__B_PWM__DBM_256_CLOCKS || \
                   PWM_ServoPorte_DeadBandMode == PWM_ServoPorte__B_PWM__DBM_2_4_CLOCKS)
                    PWM_ServoPorte_WriteDeadTime(PWM_ServoPorte_backup.PWMdeadBandValue);
                #endif /* deadband count is either 2-4 clocks or 256 clocks */
            
                #if ( PWM_ServoPorte_KillModeMinTime)
                    PWM_ServoPorte_WriteKillTime(PWM_ServoPorte_backup.PWMKillCounterPeriod);
                #endif /* ( PWM_ServoPorte_KillModeMinTime) */
            #endif /* (CY_UDB_V0) */
            
            #if (CY_UDB_V1)
                #if(!PWM_ServoPorte_PWMModeIsCenterAligned)
                    PWM_ServoPorte_WritePeriod(PWM_ServoPorte_backup.PWMPeriod);
                #endif /* (!PWM_ServoPorte_PWMModeIsCenterAligned) */
                PWM_ServoPorte_WriteCounter(PWM_ServoPorte_backup.PWMUdb);
                #if (PWM_ServoPorte_UseStatus)
                    PWM_ServoPorte_STATUS_MASK = PWM_ServoPorte_backup.InterruptMaskValue;
                #endif /* (PWM_ServoPorte_UseStatus) */
                
                #if(PWM_ServoPorte_DeadBandMode == PWM_ServoPorte__B_PWM__DBM_256_CLOCKS || \
                    PWM_ServoPorte_DeadBandMode == PWM_ServoPorte__B_PWM__DBM_2_4_CLOCKS)
                    PWM_ServoPorte_WriteDeadTime(PWM_ServoPorte_backup.PWMdeadBandValue);
                #endif /* deadband count is either 2-4 clocks or 256 clocks */
                
                #if(PWM_ServoPorte_KillModeMinTime)
                    PWM_ServoPorte_WriteKillTime(PWM_ServoPorte_backup.PWMKillCounterPeriod);
                #endif /* (PWM_ServoPorte_KillModeMinTime) */
            #endif /* (CY_UDB_V1) */
            
            #if(PWM_ServoPorte_UseControl)
                PWM_ServoPorte_WriteControlRegister(PWM_ServoPorte_backup.PWMControlRegister); 
            #endif /* (PWM_ServoPorte_UseControl) */
        #endif  /* (!PWM_ServoPorte_UsingFixedFunction) */
    }


/*******************************************************************************
* Function Name: PWM_ServoPorte_Sleep
********************************************************************************
* 
* Summary:
*  Disables block's operation and saves the user configuration. Should be called 
*  just prior to entering sleep.
*  
* Parameters:  
*  None
*
* Return: 
*  None
*
* Global variables:
*  PWM_ServoPorte_backup.PWMEnableState:  Is modified depending on the enable 
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void PWM_ServoPorte_Sleep(void) 
{
    #if(PWM_ServoPorte_UseControl)
        if(PWM_ServoPorte_CTRL_ENABLE == (PWM_ServoPorte_CONTROL & PWM_ServoPorte_CTRL_ENABLE))
        {
            /*Component is enabled */
            PWM_ServoPorte_backup.PWMEnableState = 1u;
        }
        else
        {
            /* Component is disabled */
            PWM_ServoPorte_backup.PWMEnableState = 0u;
        }
    #endif /* (PWM_ServoPorte_UseControl) */

    /* Stop component */
    PWM_ServoPorte_Stop();
    
    /* Save registers configuration */
    PWM_ServoPorte_SaveConfig();
}


/*******************************************************************************
* Function Name: PWM_ServoPorte_Wakeup
********************************************************************************
* 
* Summary:
*  Restores and enables the user configuration. Should be called just after 
*  awaking from sleep.
*  
* Parameters:  
*  None
*
* Return: 
*  None
*
* Global variables:
*  PWM_ServoPorte_backup.pwmEnable:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void PWM_ServoPorte_Wakeup(void) 
{
     /* Restore registers values */
    PWM_ServoPorte_RestoreConfig();
    
    if(PWM_ServoPorte_backup.PWMEnableState != 0u)
    {
        /* Enable component's operation */
        PWM_ServoPorte_Enable();
    } /* Do nothing if component's block was disabled before */
    
}


/* [] END OF FILE */
