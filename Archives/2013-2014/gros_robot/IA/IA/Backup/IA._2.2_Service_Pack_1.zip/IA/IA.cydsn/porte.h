/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef PORTE_H
#define PORTE_H


void libererVerre(void);
void ouvrirPorte(void);
void fermerPorte(void);
void toucherAvecPorte(void);

inline void resetTimerEmpileur(void);

#endif

//[] END OF FILE
