#ifndef DATA_H_INCLUDED
#define DATA_H_INCLUDED

#include "astar.h"
/*Une seule fonction ici, loadPointList(), qui charge dans la m�moire vive
la liste de tout les points. Il s'agit d'un code C g�n�r� � partir d'un 
autre programme*/

PointROM * loadPointList();


#endif // DATA_H_INCLUDED


