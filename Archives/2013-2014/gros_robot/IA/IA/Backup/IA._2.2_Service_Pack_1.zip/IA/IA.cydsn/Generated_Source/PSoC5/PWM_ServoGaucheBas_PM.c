/*******************************************************************************
* File Name: PWM_ServoGaucheBas_PM.c
* Version 2.40
*
* Description:
*  This file provides the power management source code to API for the
*  PWM.
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/
#include "cytypes.h"
#include "PWM_ServoGaucheBas.h"

static PWM_ServoGaucheBas_backupStruct PWM_ServoGaucheBas_backup;


/*******************************************************************************
* Function Name: PWM_ServoGaucheBas_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration of the component.
*  
* Parameters:  
*  None
*
* Return: 
*  None
*
* Global variables:
*  PWM_ServoGaucheBas_backup:  Variables of this global structure are modified to 
*  store the values of non retention configuration registers when Sleep() API is 
*  called.
*
*******************************************************************************/
void PWM_ServoGaucheBas_SaveConfig(void) 
{
    
    #if(!PWM_ServoGaucheBas_UsingFixedFunction)
        #if (CY_UDB_V0)
            PWM_ServoGaucheBas_backup.PWMUdb = PWM_ServoGaucheBas_ReadCounter();
            PWM_ServoGaucheBas_backup.PWMPeriod = PWM_ServoGaucheBas_ReadPeriod();
            #if (PWM_ServoGaucheBas_UseStatus)
                PWM_ServoGaucheBas_backup.InterruptMaskValue = PWM_ServoGaucheBas_STATUS_MASK;
            #endif /* (PWM_ServoGaucheBas_UseStatus) */
            
            #if(PWM_ServoGaucheBas_UseOneCompareMode)
                PWM_ServoGaucheBas_backup.PWMCompareValue = PWM_ServoGaucheBas_ReadCompare();
            #else
                PWM_ServoGaucheBas_backup.PWMCompareValue1 = PWM_ServoGaucheBas_ReadCompare1();
                PWM_ServoGaucheBas_backup.PWMCompareValue2 = PWM_ServoGaucheBas_ReadCompare2();
            #endif /* (PWM_ServoGaucheBas_UseOneCompareMode) */
            
           #if(PWM_ServoGaucheBas_DeadBandUsed)
                PWM_ServoGaucheBas_backup.PWMdeadBandValue = PWM_ServoGaucheBas_ReadDeadTime();
            #endif /* (PWM_ServoGaucheBas_DeadBandUsed) */
          
            #if ( PWM_ServoGaucheBas_KillModeMinTime)
                PWM_ServoGaucheBas_backup.PWMKillCounterPeriod = PWM_ServoGaucheBas_ReadKillTime();
            #endif /* ( PWM_ServoGaucheBas_KillModeMinTime) */
        #endif /* (CY_UDB_V0) */
        
        #if (CY_UDB_V1)
            #if(!PWM_ServoGaucheBas_PWMModeIsCenterAligned)
                PWM_ServoGaucheBas_backup.PWMPeriod = PWM_ServoGaucheBas_ReadPeriod();
            #endif /* (!PWM_ServoGaucheBas_PWMModeIsCenterAligned) */
            PWM_ServoGaucheBas_backup.PWMUdb = PWM_ServoGaucheBas_ReadCounter();
            #if (PWM_ServoGaucheBas_UseStatus)
                PWM_ServoGaucheBas_backup.InterruptMaskValue = PWM_ServoGaucheBas_STATUS_MASK;
            #endif /* (PWM_ServoGaucheBas_UseStatus) */
            
            #if(PWM_ServoGaucheBas_DeadBandMode == PWM_ServoGaucheBas__B_PWM__DBM_256_CLOCKS || \
                PWM_ServoGaucheBas_DeadBandMode == PWM_ServoGaucheBas__B_PWM__DBM_2_4_CLOCKS)
                PWM_ServoGaucheBas_backup.PWMdeadBandValue = PWM_ServoGaucheBas_ReadDeadTime();
            #endif /*  deadband count is either 2-4 clocks or 256 clocks */
            
            #if(PWM_ServoGaucheBas_KillModeMinTime)
                 PWM_ServoGaucheBas_backup.PWMKillCounterPeriod = PWM_ServoGaucheBas_ReadKillTime();
            #endif /* (PWM_ServoGaucheBas_KillModeMinTime) */
        #endif /* (CY_UDB_V1) */
        
        #if(PWM_ServoGaucheBas_UseControl)
            PWM_ServoGaucheBas_backup.PWMControlRegister = PWM_ServoGaucheBas_ReadControlRegister();
        #endif /* (PWM_ServoGaucheBas_UseControl) */
    #endif  /* (!PWM_ServoGaucheBas_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: PWM_ServoGaucheBas_RestoreConfig
********************************************************************************
* 
* Summary:
*  Restores the current user configuration of the component.
*
* Parameters:  
*  None
*
* Return: 
*  None
*
* Global variables:
*  PWM_ServoGaucheBas_backup:  Variables of this global structure are used to  
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void PWM_ServoGaucheBas_RestoreConfig(void) 
{
        #if(!PWM_ServoGaucheBas_UsingFixedFunction)
            #if (CY_UDB_V0)
                /* Interrupt State Backup for Critical Region*/
                uint8 PWM_ServoGaucheBas_interruptState;
                /* Enter Critical Region*/
                PWM_ServoGaucheBas_interruptState = CyEnterCriticalSection();
                #if (PWM_ServoGaucheBas_UseStatus)
                    /* Use the interrupt output of the status register for IRQ output */
                    PWM_ServoGaucheBas_STATUS_AUX_CTRL |= PWM_ServoGaucheBas_STATUS_ACTL_INT_EN_MASK;
                    
                    PWM_ServoGaucheBas_STATUS_MASK = PWM_ServoGaucheBas_backup.InterruptMaskValue;
                #endif /* (PWM_ServoGaucheBas_UseStatus) */
                
                #if (PWM_ServoGaucheBas_Resolution == 8)
                    /* Set FIFO 0 to 1 byte register for period*/
                    PWM_ServoGaucheBas_AUX_CONTROLDP0 |= (PWM_ServoGaucheBas_AUX_CTRL_FIFO0_CLR);
                #else /* (PWM_ServoGaucheBas_Resolution == 16)*/
                    /* Set FIFO 0 to 1 byte register for period */
                    PWM_ServoGaucheBas_AUX_CONTROLDP0 |= (PWM_ServoGaucheBas_AUX_CTRL_FIFO0_CLR);
                    PWM_ServoGaucheBas_AUX_CONTROLDP1 |= (PWM_ServoGaucheBas_AUX_CTRL_FIFO0_CLR);
                #endif /* (PWM_ServoGaucheBas_Resolution == 8) */
                /* Exit Critical Region*/
                CyExitCriticalSection(PWM_ServoGaucheBas_interruptState);
                
                PWM_ServoGaucheBas_WriteCounter(PWM_ServoGaucheBas_backup.PWMUdb);
                PWM_ServoGaucheBas_WritePeriod(PWM_ServoGaucheBas_backup.PWMPeriod);
                
                #if(PWM_ServoGaucheBas_UseOneCompareMode)
                    PWM_ServoGaucheBas_WriteCompare(PWM_ServoGaucheBas_backup.PWMCompareValue);
                #else
                    PWM_ServoGaucheBas_WriteCompare1(PWM_ServoGaucheBas_backup.PWMCompareValue1);
                    PWM_ServoGaucheBas_WriteCompare2(PWM_ServoGaucheBas_backup.PWMCompareValue2);
                #endif /* (PWM_ServoGaucheBas_UseOneCompareMode) */
                
               #if(PWM_ServoGaucheBas_DeadBandMode == PWM_ServoGaucheBas__B_PWM__DBM_256_CLOCKS || \
                   PWM_ServoGaucheBas_DeadBandMode == PWM_ServoGaucheBas__B_PWM__DBM_2_4_CLOCKS)
                    PWM_ServoGaucheBas_WriteDeadTime(PWM_ServoGaucheBas_backup.PWMdeadBandValue);
                #endif /* deadband count is either 2-4 clocks or 256 clocks */
            
                #if ( PWM_ServoGaucheBas_KillModeMinTime)
                    PWM_ServoGaucheBas_WriteKillTime(PWM_ServoGaucheBas_backup.PWMKillCounterPeriod);
                #endif /* ( PWM_ServoGaucheBas_KillModeMinTime) */
            #endif /* (CY_UDB_V0) */
            
            #if (CY_UDB_V1)
                #if(!PWM_ServoGaucheBas_PWMModeIsCenterAligned)
                    PWM_ServoGaucheBas_WritePeriod(PWM_ServoGaucheBas_backup.PWMPeriod);
                #endif /* (!PWM_ServoGaucheBas_PWMModeIsCenterAligned) */
                PWM_ServoGaucheBas_WriteCounter(PWM_ServoGaucheBas_backup.PWMUdb);
                #if (PWM_ServoGaucheBas_UseStatus)
                    PWM_ServoGaucheBas_STATUS_MASK = PWM_ServoGaucheBas_backup.InterruptMaskValue;
                #endif /* (PWM_ServoGaucheBas_UseStatus) */
                
                #if(PWM_ServoGaucheBas_DeadBandMode == PWM_ServoGaucheBas__B_PWM__DBM_256_CLOCKS || \
                    PWM_ServoGaucheBas_DeadBandMode == PWM_ServoGaucheBas__B_PWM__DBM_2_4_CLOCKS)
                    PWM_ServoGaucheBas_WriteDeadTime(PWM_ServoGaucheBas_backup.PWMdeadBandValue);
                #endif /* deadband count is either 2-4 clocks or 256 clocks */
                
                #if(PWM_ServoGaucheBas_KillModeMinTime)
                    PWM_ServoGaucheBas_WriteKillTime(PWM_ServoGaucheBas_backup.PWMKillCounterPeriod);
                #endif /* (PWM_ServoGaucheBas_KillModeMinTime) */
            #endif /* (CY_UDB_V1) */
            
            #if(PWM_ServoGaucheBas_UseControl)
                PWM_ServoGaucheBas_WriteControlRegister(PWM_ServoGaucheBas_backup.PWMControlRegister); 
            #endif /* (PWM_ServoGaucheBas_UseControl) */
        #endif  /* (!PWM_ServoGaucheBas_UsingFixedFunction) */
    }


/*******************************************************************************
* Function Name: PWM_ServoGaucheBas_Sleep
********************************************************************************
* 
* Summary:
*  Disables block's operation and saves the user configuration. Should be called 
*  just prior to entering sleep.
*  
* Parameters:  
*  None
*
* Return: 
*  None
*
* Global variables:
*  PWM_ServoGaucheBas_backup.PWMEnableState:  Is modified depending on the enable 
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void PWM_ServoGaucheBas_Sleep(void) 
{
    #if(PWM_ServoGaucheBas_UseControl)
        if(PWM_ServoGaucheBas_CTRL_ENABLE == (PWM_ServoGaucheBas_CONTROL & PWM_ServoGaucheBas_CTRL_ENABLE))
        {
            /*Component is enabled */
            PWM_ServoGaucheBas_backup.PWMEnableState = 1u;
        }
        else
        {
            /* Component is disabled */
            PWM_ServoGaucheBas_backup.PWMEnableState = 0u;
        }
    #endif /* (PWM_ServoGaucheBas_UseControl) */

    /* Stop component */
    PWM_ServoGaucheBas_Stop();
    
    /* Save registers configuration */
    PWM_ServoGaucheBas_SaveConfig();
}


/*******************************************************************************
* Function Name: PWM_ServoGaucheBas_Wakeup
********************************************************************************
* 
* Summary:
*  Restores and enables the user configuration. Should be called just after 
*  awaking from sleep.
*  
* Parameters:  
*  None
*
* Return: 
*  None
*
* Global variables:
*  PWM_ServoGaucheBas_backup.pwmEnable:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void PWM_ServoGaucheBas_Wakeup(void) 
{
     /* Restore registers values */
    PWM_ServoGaucheBas_RestoreConfig();
    
    if(PWM_ServoGaucheBas_backup.PWMEnableState != 0u)
    {
        /* Enable component's operation */
        PWM_ServoGaucheBas_Enable();
    } /* Do nothing if component's block was disabled before */
    
}


/* [] END OF FILE */
