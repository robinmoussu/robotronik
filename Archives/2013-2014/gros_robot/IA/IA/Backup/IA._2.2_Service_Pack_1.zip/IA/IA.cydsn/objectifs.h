/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef OBJECTIFS_H
#define OBJECTIFS_H

#include "constantes.h"

void initObjectifs(void);
void forgerObjectif(Mission * m, Objectif o);

#endif // OBJECTIFS_H
//[] END OF FILE
