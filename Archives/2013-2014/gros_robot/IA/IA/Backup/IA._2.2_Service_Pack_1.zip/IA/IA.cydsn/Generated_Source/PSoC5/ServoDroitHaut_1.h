/*******************************************************************************
* File Name: ServoDroitHaut_1.h  
* Version 1.60
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#if !defined(CY_PINS_ServoDroitHaut_1_H) /* Pins ServoDroitHaut_1_H */
#define CY_PINS_ServoDroitHaut_1_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "ServoDroitHaut_1_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CYDEV_CHIP_FAMILY_USED == CYDEV_CHIP_FAMILY_PSOC5 &&\
     CYDEV_CHIP_REVISION_USED == CYDEV_CHIP_REVISION_5A_PRODUCTION &&\
	 ServoDroitHaut_1__PORT == 15 && (ServoDroitHaut_1__MASK & 0xC0))

/***************************************
*        Function Prototypes             
***************************************/    

void    ServoDroitHaut_1_Write(uint8 value) ;
void    ServoDroitHaut_1_SetDriveMode(uint8 mode) ;
uint8   ServoDroitHaut_1_ReadDataReg(void) ;
uint8   ServoDroitHaut_1_Read(void) ;
uint8   ServoDroitHaut_1_ClearInterrupt(void) ;

/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define ServoDroitHaut_1_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define ServoDroitHaut_1_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define ServoDroitHaut_1_DM_RES_UP          PIN_DM_RES_UP
#define ServoDroitHaut_1_DM_RES_DWN         PIN_DM_RES_DWN
#define ServoDroitHaut_1_DM_OD_LO           PIN_DM_OD_LO
#define ServoDroitHaut_1_DM_OD_HI           PIN_DM_OD_HI
#define ServoDroitHaut_1_DM_STRONG          PIN_DM_STRONG
#define ServoDroitHaut_1_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define ServoDroitHaut_1_MASK               ServoDroitHaut_1__MASK
#define ServoDroitHaut_1_SHIFT              ServoDroitHaut_1__SHIFT
#define ServoDroitHaut_1_WIDTH              1u

/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define ServoDroitHaut_1_PS                     (* (reg8 *) ServoDroitHaut_1__PS)
/* Data Register */
#define ServoDroitHaut_1_DR                     (* (reg8 *) ServoDroitHaut_1__DR)
/* Port Number */
#define ServoDroitHaut_1_PRT_NUM                (* (reg8 *) ServoDroitHaut_1__PRT) 
/* Connect to Analog Globals */                                                  
#define ServoDroitHaut_1_AG                     (* (reg8 *) ServoDroitHaut_1__AG)                       
/* Analog MUX bux enable */
#define ServoDroitHaut_1_AMUX                   (* (reg8 *) ServoDroitHaut_1__AMUX) 
/* Bidirectional Enable */                                                        
#define ServoDroitHaut_1_BIE                    (* (reg8 *) ServoDroitHaut_1__BIE)
/* Bit-mask for Aliased Register Access */
#define ServoDroitHaut_1_BIT_MASK               (* (reg8 *) ServoDroitHaut_1__BIT_MASK)
/* Bypass Enable */
#define ServoDroitHaut_1_BYP                    (* (reg8 *) ServoDroitHaut_1__BYP)
/* Port wide control signals */                                                   
#define ServoDroitHaut_1_CTL                    (* (reg8 *) ServoDroitHaut_1__CTL)
/* Drive Modes */
#define ServoDroitHaut_1_DM0                    (* (reg8 *) ServoDroitHaut_1__DM0) 
#define ServoDroitHaut_1_DM1                    (* (reg8 *) ServoDroitHaut_1__DM1)
#define ServoDroitHaut_1_DM2                    (* (reg8 *) ServoDroitHaut_1__DM2) 
/* Input Buffer Disable Override */
#define ServoDroitHaut_1_INP_DIS                (* (reg8 *) ServoDroitHaut_1__INP_DIS)
/* LCD Common or Segment Drive */
#define ServoDroitHaut_1_LCD_COM_SEG            (* (reg8 *) ServoDroitHaut_1__LCD_COM_SEG)
/* Enable Segment LCD */
#define ServoDroitHaut_1_LCD_EN                 (* (reg8 *) ServoDroitHaut_1__LCD_EN)
/* Slew Rate Control */
#define ServoDroitHaut_1_SLW                    (* (reg8 *) ServoDroitHaut_1__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define ServoDroitHaut_1_PRTDSI__CAPS_SEL       (* (reg8 *) ServoDroitHaut_1__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define ServoDroitHaut_1_PRTDSI__DBL_SYNC_IN    (* (reg8 *) ServoDroitHaut_1__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define ServoDroitHaut_1_PRTDSI__OE_SEL0        (* (reg8 *) ServoDroitHaut_1__PRTDSI__OE_SEL0) 
#define ServoDroitHaut_1_PRTDSI__OE_SEL1        (* (reg8 *) ServoDroitHaut_1__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define ServoDroitHaut_1_PRTDSI__OUT_SEL0       (* (reg8 *) ServoDroitHaut_1__PRTDSI__OUT_SEL0) 
#define ServoDroitHaut_1_PRTDSI__OUT_SEL1       (* (reg8 *) ServoDroitHaut_1__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define ServoDroitHaut_1_PRTDSI__SYNC_OUT       (* (reg8 *) ServoDroitHaut_1__PRTDSI__SYNC_OUT) 


#if defined(ServoDroitHaut_1__INTSTAT)  /* Interrupt Registers */

    #define ServoDroitHaut_1_INTSTAT                (* (reg8 *) ServoDroitHaut_1__INTSTAT)
    #define ServoDroitHaut_1_SNAP                   (* (reg8 *) ServoDroitHaut_1__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins ServoDroitHaut_1_H */

#endif
/* [] END OF FILE */
