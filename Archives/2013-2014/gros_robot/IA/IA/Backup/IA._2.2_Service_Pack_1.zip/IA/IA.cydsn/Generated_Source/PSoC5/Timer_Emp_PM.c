/*******************************************************************************
* File Name: Timer_Emp_PM.c
* Version 2.50
*
*  Description:
*     This file provides the power management source code to API for the
*     Timer.
*
*   Note:
*     None
*
*******************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#include "Timer_Emp.h"
static Timer_Emp_backupStruct Timer_Emp_backup;


/*******************************************************************************
* Function Name: Timer_Emp_SaveConfig
********************************************************************************
*
* Summary:
*     Save the current user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_Emp_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void Timer_Emp_SaveConfig(void) 
{
    #if (!Timer_Emp_UsingFixedFunction)
        /* Backup the UDB non-rentention registers for CY_UDB_V0 */
        #if (CY_UDB_V0)
            Timer_Emp_backup.TimerUdb = Timer_Emp_ReadCounter();
            Timer_Emp_backup.TimerPeriod = Timer_Emp_ReadPeriod();
            Timer_Emp_backup.InterruptMaskValue = Timer_Emp_STATUS_MASK;
            #if (Timer_Emp_UsingHWCaptureCounter)
                Timer_Emp_backup.TimerCaptureCounter = Timer_Emp_ReadCaptureCount();
            #endif /* Backup the UDB non-rentention register capture counter for CY_UDB_V0 */
        #endif /* Backup the UDB non-rentention registers for CY_UDB_V0 */

        #if (CY_UDB_V1)
            Timer_Emp_backup.TimerUdb = Timer_Emp_ReadCounter();
            Timer_Emp_backup.InterruptMaskValue = Timer_Emp_STATUS_MASK;
            #if (Timer_Emp_UsingHWCaptureCounter)
                Timer_Emp_backup.TimerCaptureCounter = Timer_Emp_ReadCaptureCount();
            #endif /* Back Up capture counter register  */
        #endif /* Backup non retention registers, interrupt mask and capture counter for CY_UDB_V1 */

        #if(!Timer_Emp_ControlRegRemoved)
            Timer_Emp_backup.TimerControlRegister = Timer_Emp_ReadControlRegister();
        #endif /* Backup the enable state of the Timer component */
    #endif /* Backup non retention registers in UDB implementation. All fixed function registers are retention */
}


/*******************************************************************************
* Function Name: Timer_Emp_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_Emp_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void Timer_Emp_RestoreConfig(void) 
{   
    #if (!Timer_Emp_UsingFixedFunction)
        /* Restore the UDB non-rentention registers for CY_UDB_V0 */
        #if (CY_UDB_V0)
            /* Interrupt State Backup for Critical Region*/
            uint8 Timer_Emp_interruptState;

            Timer_Emp_WriteCounter(Timer_Emp_backup.TimerUdb);
            Timer_Emp_WritePeriod(Timer_Emp_backup.TimerPeriod);
            /* CyEnterCriticalRegion and CyExitCriticalRegion are used to mark following region critical*/
            /* Enter Critical Region*/
            Timer_Emp_interruptState = CyEnterCriticalSection();
            /* Use the interrupt output of the status register for IRQ output */
            Timer_Emp_STATUS_AUX_CTRL |= Timer_Emp_STATUS_ACTL_INT_EN_MASK;
            /* Exit Critical Region*/
            CyExitCriticalSection(Timer_Emp_interruptState);
            Timer_Emp_STATUS_MASK =Timer_Emp_backup.InterruptMaskValue;
            #if (Timer_Emp_UsingHWCaptureCounter)
                Timer_Emp_SetCaptureCount(Timer_Emp_backup.TimerCaptureCounter);
            #endif /* Restore the UDB non-rentention register capture counter for CY_UDB_V0 */
        #endif /* Restore the UDB non-rentention registers for CY_UDB_V0 */

        #if (CY_UDB_V1)
            Timer_Emp_WriteCounter(Timer_Emp_backup.TimerUdb);
            Timer_Emp_STATUS_MASK =Timer_Emp_backup.InterruptMaskValue;
            #if (Timer_Emp_UsingHWCaptureCounter)
                Timer_Emp_SetCaptureCount(Timer_Emp_backup.TimerCaptureCounter);
            #endif /* Restore Capture counter register*/
        #endif /* Restore up non retention registers, interrupt mask and capture counter for CY_UDB_V1 */

        #if(!Timer_Emp_ControlRegRemoved)
            Timer_Emp_WriteControlRegister(Timer_Emp_backup.TimerControlRegister);
        #endif /* Restore the enable state of the Timer component */
    #endif /* Restore non retention registers in the UDB implementation only */
}


/*******************************************************************************
* Function Name: Timer_Emp_Sleep
********************************************************************************
*
* Summary:
*     Stop and Save the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_Emp_backup.TimerEnableState:  Is modified depending on the
*  enable state of the block before entering sleep mode.
*
*******************************************************************************/
void Timer_Emp_Sleep(void) 
{
    #if(!Timer_Emp_ControlRegRemoved)
        /* Save Counter's enable state */
        if(Timer_Emp_CTRL_ENABLE == (Timer_Emp_CONTROL & Timer_Emp_CTRL_ENABLE))
        {
            /* Timer is enabled */
            Timer_Emp_backup.TimerEnableState = 1u;
        }
        else
        {
            /* Timer is disabled */
            Timer_Emp_backup.TimerEnableState = 0u;
        }
    #endif /* Back up enable state from the Timer control register */
    Timer_Emp_Stop();
    Timer_Emp_SaveConfig();
}


/*******************************************************************************
* Function Name: Timer_Emp_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_Emp_backup.enableState:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void Timer_Emp_Wakeup(void) 
{
    Timer_Emp_RestoreConfig();
    #if(!Timer_Emp_ControlRegRemoved)
        if(Timer_Emp_backup.TimerEnableState == 1u)
        {     /* Enable Timer's operation */
                Timer_Emp_Enable();
        } /* Do nothing if Timer was disabled before */
    #endif /* Remove this code section if Control register is removed */
}


/* [] END OF FILE */
