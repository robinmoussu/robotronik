/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef TEMPS_H
#define TEMPS_H

#define TEMPS_FIN_S  87

void checkTemps(void);

#endif //TEMPS_H
//[] END OF FILE
