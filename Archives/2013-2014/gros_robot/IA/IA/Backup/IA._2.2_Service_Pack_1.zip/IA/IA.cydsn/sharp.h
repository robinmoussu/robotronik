#ifndef SHARP_H
#define SHARP_H

#define SEUIL15 8533 //c'est de la merde
#define SEUIL30 14000//11100


void checkPos();
void enableDetection(void);
void disableDetection(void);

#endif 