/*******************************************************************************
* File Name: UnHzISR.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_UnHzISR_H)
#define CY_ISR_UnHzISR_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void UnHzISR_Start(void);
void UnHzISR_StartEx(cyisraddress address);
void UnHzISR_Stop(void);

CY_ISR_PROTO(UnHzISR_Interrupt);

void UnHzISR_SetVector(cyisraddress address);
cyisraddress UnHzISR_GetVector(void);

void UnHzISR_SetPriority(uint8 priority);
uint8 UnHzISR_GetPriority(void);

void UnHzISR_Enable(void);
uint8 UnHzISR_GetState(void);
void UnHzISR_Disable(void);

void UnHzISR_SetPending(void);
void UnHzISR_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the UnHzISR ISR. */
#define UnHzISR_INTC_VECTOR            ((reg32 *) UnHzISR__INTC_VECT)

/* Address of the UnHzISR ISR priority. */
#define UnHzISR_INTC_PRIOR             ((reg8 *) UnHzISR__INTC_PRIOR_REG)

/* Priority of the UnHzISR interrupt. */
#define UnHzISR_INTC_PRIOR_NUMBER      UnHzISR__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable UnHzISR interrupt. */
#define UnHzISR_INTC_SET_EN            ((reg32 *) UnHzISR__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the UnHzISR interrupt. */
#define UnHzISR_INTC_CLR_EN            ((reg32 *) UnHzISR__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the UnHzISR interrupt state to pending. */
#define UnHzISR_INTC_SET_PD            ((reg32 *) UnHzISR__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the UnHzISR interrupt. */
#define UnHzISR_INTC_CLR_PD            ((reg32 *) UnHzISR__INTC_CLR_PD_REG)


#endif /* CY_ISR_UnHzISR_H */


/* [] END OF FILE */
