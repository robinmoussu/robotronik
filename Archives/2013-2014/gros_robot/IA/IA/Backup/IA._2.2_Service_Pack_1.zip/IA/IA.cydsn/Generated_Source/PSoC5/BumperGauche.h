/*******************************************************************************
* File Name: BumperGauche.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_BumperGauche_H) /* Pins BumperGauche_H */
#define CY_PINS_BumperGauche_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "BumperGauche_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v1_90 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 BumperGauche__PORT == 15 && ((BumperGauche__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    BumperGauche_Write(uint8 value) ;
void    BumperGauche_SetDriveMode(uint8 mode) ;
uint8   BumperGauche_ReadDataReg(void) ;
uint8   BumperGauche_Read(void) ;
uint8   BumperGauche_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define BumperGauche_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define BumperGauche_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define BumperGauche_DM_RES_UP          PIN_DM_RES_UP
#define BumperGauche_DM_RES_DWN         PIN_DM_RES_DWN
#define BumperGauche_DM_OD_LO           PIN_DM_OD_LO
#define BumperGauche_DM_OD_HI           PIN_DM_OD_HI
#define BumperGauche_DM_STRONG          PIN_DM_STRONG
#define BumperGauche_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define BumperGauche_MASK               BumperGauche__MASK
#define BumperGauche_SHIFT              BumperGauche__SHIFT
#define BumperGauche_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define BumperGauche_PS                     (* (reg8 *) BumperGauche__PS)
/* Data Register */
#define BumperGauche_DR                     (* (reg8 *) BumperGauche__DR)
/* Port Number */
#define BumperGauche_PRT_NUM                (* (reg8 *) BumperGauche__PRT) 
/* Connect to Analog Globals */                                                  
#define BumperGauche_AG                     (* (reg8 *) BumperGauche__AG)                       
/* Analog MUX bux enable */
#define BumperGauche_AMUX                   (* (reg8 *) BumperGauche__AMUX) 
/* Bidirectional Enable */                                                        
#define BumperGauche_BIE                    (* (reg8 *) BumperGauche__BIE)
/* Bit-mask for Aliased Register Access */
#define BumperGauche_BIT_MASK               (* (reg8 *) BumperGauche__BIT_MASK)
/* Bypass Enable */
#define BumperGauche_BYP                    (* (reg8 *) BumperGauche__BYP)
/* Port wide control signals */                                                   
#define BumperGauche_CTL                    (* (reg8 *) BumperGauche__CTL)
/* Drive Modes */
#define BumperGauche_DM0                    (* (reg8 *) BumperGauche__DM0) 
#define BumperGauche_DM1                    (* (reg8 *) BumperGauche__DM1)
#define BumperGauche_DM2                    (* (reg8 *) BumperGauche__DM2) 
/* Input Buffer Disable Override */
#define BumperGauche_INP_DIS                (* (reg8 *) BumperGauche__INP_DIS)
/* LCD Common or Segment Drive */
#define BumperGauche_LCD_COM_SEG            (* (reg8 *) BumperGauche__LCD_COM_SEG)
/* Enable Segment LCD */
#define BumperGauche_LCD_EN                 (* (reg8 *) BumperGauche__LCD_EN)
/* Slew Rate Control */
#define BumperGauche_SLW                    (* (reg8 *) BumperGauche__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define BumperGauche_PRTDSI__CAPS_SEL       (* (reg8 *) BumperGauche__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define BumperGauche_PRTDSI__DBL_SYNC_IN    (* (reg8 *) BumperGauche__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define BumperGauche_PRTDSI__OE_SEL0        (* (reg8 *) BumperGauche__PRTDSI__OE_SEL0) 
#define BumperGauche_PRTDSI__OE_SEL1        (* (reg8 *) BumperGauche__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define BumperGauche_PRTDSI__OUT_SEL0       (* (reg8 *) BumperGauche__PRTDSI__OUT_SEL0) 
#define BumperGauche_PRTDSI__OUT_SEL1       (* (reg8 *) BumperGauche__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define BumperGauche_PRTDSI__SYNC_OUT       (* (reg8 *) BumperGauche__PRTDSI__SYNC_OUT) 


#if defined(BumperGauche__INTSTAT)  /* Interrupt Registers */

    #define BumperGauche_INTSTAT                (* (reg8 *) BumperGauche__INTSTAT)
    #define BumperGauche_SNAP                   (* (reg8 *) BumperGauche__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_BumperGauche_H */


/* [] END OF FILE */
