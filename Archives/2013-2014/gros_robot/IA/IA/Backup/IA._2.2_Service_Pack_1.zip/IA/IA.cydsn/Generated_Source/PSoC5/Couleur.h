/*******************************************************************************
* File Name: Couleur.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Couleur_H) /* Pins Couleur_H */
#define CY_PINS_Couleur_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Couleur_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v1_90 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Couleur__PORT == 15 && ((Couleur__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    Couleur_Write(uint8 value) ;
void    Couleur_SetDriveMode(uint8 mode) ;
uint8   Couleur_ReadDataReg(void) ;
uint8   Couleur_Read(void) ;
uint8   Couleur_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Couleur_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define Couleur_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define Couleur_DM_RES_UP          PIN_DM_RES_UP
#define Couleur_DM_RES_DWN         PIN_DM_RES_DWN
#define Couleur_DM_OD_LO           PIN_DM_OD_LO
#define Couleur_DM_OD_HI           PIN_DM_OD_HI
#define Couleur_DM_STRONG          PIN_DM_STRONG
#define Couleur_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define Couleur_MASK               Couleur__MASK
#define Couleur_SHIFT              Couleur__SHIFT
#define Couleur_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Couleur_PS                     (* (reg8 *) Couleur__PS)
/* Data Register */
#define Couleur_DR                     (* (reg8 *) Couleur__DR)
/* Port Number */
#define Couleur_PRT_NUM                (* (reg8 *) Couleur__PRT) 
/* Connect to Analog Globals */                                                  
#define Couleur_AG                     (* (reg8 *) Couleur__AG)                       
/* Analog MUX bux enable */
#define Couleur_AMUX                   (* (reg8 *) Couleur__AMUX) 
/* Bidirectional Enable */                                                        
#define Couleur_BIE                    (* (reg8 *) Couleur__BIE)
/* Bit-mask for Aliased Register Access */
#define Couleur_BIT_MASK               (* (reg8 *) Couleur__BIT_MASK)
/* Bypass Enable */
#define Couleur_BYP                    (* (reg8 *) Couleur__BYP)
/* Port wide control signals */                                                   
#define Couleur_CTL                    (* (reg8 *) Couleur__CTL)
/* Drive Modes */
#define Couleur_DM0                    (* (reg8 *) Couleur__DM0) 
#define Couleur_DM1                    (* (reg8 *) Couleur__DM1)
#define Couleur_DM2                    (* (reg8 *) Couleur__DM2) 
/* Input Buffer Disable Override */
#define Couleur_INP_DIS                (* (reg8 *) Couleur__INP_DIS)
/* LCD Common or Segment Drive */
#define Couleur_LCD_COM_SEG            (* (reg8 *) Couleur__LCD_COM_SEG)
/* Enable Segment LCD */
#define Couleur_LCD_EN                 (* (reg8 *) Couleur__LCD_EN)
/* Slew Rate Control */
#define Couleur_SLW                    (* (reg8 *) Couleur__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Couleur_PRTDSI__CAPS_SEL       (* (reg8 *) Couleur__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Couleur_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Couleur__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Couleur_PRTDSI__OE_SEL0        (* (reg8 *) Couleur__PRTDSI__OE_SEL0) 
#define Couleur_PRTDSI__OE_SEL1        (* (reg8 *) Couleur__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Couleur_PRTDSI__OUT_SEL0       (* (reg8 *) Couleur__PRTDSI__OUT_SEL0) 
#define Couleur_PRTDSI__OUT_SEL1       (* (reg8 *) Couleur__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Couleur_PRTDSI__SYNC_OUT       (* (reg8 *) Couleur__PRTDSI__SYNC_OUT) 


#if defined(Couleur__INTSTAT)  /* Interrupt Registers */

    #define Couleur_INTSTAT                (* (reg8 *) Couleur__INTSTAT)
    #define Couleur_SNAP                   (* (reg8 *) Couleur__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Couleur_H */


/* [] END OF FILE */
