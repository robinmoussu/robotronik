/*******************************************************************************
* File Name: PWM_ServoGaucheHaut_PM.c
* Version 2.40
*
* Description:
*  This file provides the power management source code to API for the
*  PWM.
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/
#include "cytypes.h"
#include "PWM_ServoGaucheHaut.h"

static PWM_ServoGaucheHaut_backupStruct PWM_ServoGaucheHaut_backup;


/*******************************************************************************
* Function Name: PWM_ServoGaucheHaut_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration of the component.
*  
* Parameters:  
*  None
*
* Return: 
*  None
*
* Global variables:
*  PWM_ServoGaucheHaut_backup:  Variables of this global structure are modified to 
*  store the values of non retention configuration registers when Sleep() API is 
*  called.
*
*******************************************************************************/
void PWM_ServoGaucheHaut_SaveConfig(void) 
{
    
    #if(!PWM_ServoGaucheHaut_UsingFixedFunction)
        #if (CY_UDB_V0)
            PWM_ServoGaucheHaut_backup.PWMUdb = PWM_ServoGaucheHaut_ReadCounter();
            PWM_ServoGaucheHaut_backup.PWMPeriod = PWM_ServoGaucheHaut_ReadPeriod();
            #if (PWM_ServoGaucheHaut_UseStatus)
                PWM_ServoGaucheHaut_backup.InterruptMaskValue = PWM_ServoGaucheHaut_STATUS_MASK;
            #endif /* (PWM_ServoGaucheHaut_UseStatus) */
            
            #if(PWM_ServoGaucheHaut_UseOneCompareMode)
                PWM_ServoGaucheHaut_backup.PWMCompareValue = PWM_ServoGaucheHaut_ReadCompare();
            #else
                PWM_ServoGaucheHaut_backup.PWMCompareValue1 = PWM_ServoGaucheHaut_ReadCompare1();
                PWM_ServoGaucheHaut_backup.PWMCompareValue2 = PWM_ServoGaucheHaut_ReadCompare2();
            #endif /* (PWM_ServoGaucheHaut_UseOneCompareMode) */
            
           #if(PWM_ServoGaucheHaut_DeadBandUsed)
                PWM_ServoGaucheHaut_backup.PWMdeadBandValue = PWM_ServoGaucheHaut_ReadDeadTime();
            #endif /* (PWM_ServoGaucheHaut_DeadBandUsed) */
          
            #if ( PWM_ServoGaucheHaut_KillModeMinTime)
                PWM_ServoGaucheHaut_backup.PWMKillCounterPeriod = PWM_ServoGaucheHaut_ReadKillTime();
            #endif /* ( PWM_ServoGaucheHaut_KillModeMinTime) */
        #endif /* (CY_UDB_V0) */
        
        #if (CY_UDB_V1)
            #if(!PWM_ServoGaucheHaut_PWMModeIsCenterAligned)
                PWM_ServoGaucheHaut_backup.PWMPeriod = PWM_ServoGaucheHaut_ReadPeriod();
            #endif /* (!PWM_ServoGaucheHaut_PWMModeIsCenterAligned) */
            PWM_ServoGaucheHaut_backup.PWMUdb = PWM_ServoGaucheHaut_ReadCounter();
            #if (PWM_ServoGaucheHaut_UseStatus)
                PWM_ServoGaucheHaut_backup.InterruptMaskValue = PWM_ServoGaucheHaut_STATUS_MASK;
            #endif /* (PWM_ServoGaucheHaut_UseStatus) */
            
            #if(PWM_ServoGaucheHaut_DeadBandMode == PWM_ServoGaucheHaut__B_PWM__DBM_256_CLOCKS || \
                PWM_ServoGaucheHaut_DeadBandMode == PWM_ServoGaucheHaut__B_PWM__DBM_2_4_CLOCKS)
                PWM_ServoGaucheHaut_backup.PWMdeadBandValue = PWM_ServoGaucheHaut_ReadDeadTime();
            #endif /*  deadband count is either 2-4 clocks or 256 clocks */
            
            #if(PWM_ServoGaucheHaut_KillModeMinTime)
                 PWM_ServoGaucheHaut_backup.PWMKillCounterPeriod = PWM_ServoGaucheHaut_ReadKillTime();
            #endif /* (PWM_ServoGaucheHaut_KillModeMinTime) */
        #endif /* (CY_UDB_V1) */
        
        #if(PWM_ServoGaucheHaut_UseControl)
            PWM_ServoGaucheHaut_backup.PWMControlRegister = PWM_ServoGaucheHaut_ReadControlRegister();
        #endif /* (PWM_ServoGaucheHaut_UseControl) */
    #endif  /* (!PWM_ServoGaucheHaut_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: PWM_ServoGaucheHaut_RestoreConfig
********************************************************************************
* 
* Summary:
*  Restores the current user configuration of the component.
*
* Parameters:  
*  None
*
* Return: 
*  None
*
* Global variables:
*  PWM_ServoGaucheHaut_backup:  Variables of this global structure are used to  
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void PWM_ServoGaucheHaut_RestoreConfig(void) 
{
        #if(!PWM_ServoGaucheHaut_UsingFixedFunction)
            #if (CY_UDB_V0)
                /* Interrupt State Backup for Critical Region*/
                uint8 PWM_ServoGaucheHaut_interruptState;
                /* Enter Critical Region*/
                PWM_ServoGaucheHaut_interruptState = CyEnterCriticalSection();
                #if (PWM_ServoGaucheHaut_UseStatus)
                    /* Use the interrupt output of the status register for IRQ output */
                    PWM_ServoGaucheHaut_STATUS_AUX_CTRL |= PWM_ServoGaucheHaut_STATUS_ACTL_INT_EN_MASK;
                    
                    PWM_ServoGaucheHaut_STATUS_MASK = PWM_ServoGaucheHaut_backup.InterruptMaskValue;
                #endif /* (PWM_ServoGaucheHaut_UseStatus) */
                
                #if (PWM_ServoGaucheHaut_Resolution == 8)
                    /* Set FIFO 0 to 1 byte register for period*/
                    PWM_ServoGaucheHaut_AUX_CONTROLDP0 |= (PWM_ServoGaucheHaut_AUX_CTRL_FIFO0_CLR);
                #else /* (PWM_ServoGaucheHaut_Resolution == 16)*/
                    /* Set FIFO 0 to 1 byte register for period */
                    PWM_ServoGaucheHaut_AUX_CONTROLDP0 |= (PWM_ServoGaucheHaut_AUX_CTRL_FIFO0_CLR);
                    PWM_ServoGaucheHaut_AUX_CONTROLDP1 |= (PWM_ServoGaucheHaut_AUX_CTRL_FIFO0_CLR);
                #endif /* (PWM_ServoGaucheHaut_Resolution == 8) */
                /* Exit Critical Region*/
                CyExitCriticalSection(PWM_ServoGaucheHaut_interruptState);
                
                PWM_ServoGaucheHaut_WriteCounter(PWM_ServoGaucheHaut_backup.PWMUdb);
                PWM_ServoGaucheHaut_WritePeriod(PWM_ServoGaucheHaut_backup.PWMPeriod);
                
                #if(PWM_ServoGaucheHaut_UseOneCompareMode)
                    PWM_ServoGaucheHaut_WriteCompare(PWM_ServoGaucheHaut_backup.PWMCompareValue);
                #else
                    PWM_ServoGaucheHaut_WriteCompare1(PWM_ServoGaucheHaut_backup.PWMCompareValue1);
                    PWM_ServoGaucheHaut_WriteCompare2(PWM_ServoGaucheHaut_backup.PWMCompareValue2);
                #endif /* (PWM_ServoGaucheHaut_UseOneCompareMode) */
                
               #if(PWM_ServoGaucheHaut_DeadBandMode == PWM_ServoGaucheHaut__B_PWM__DBM_256_CLOCKS || \
                   PWM_ServoGaucheHaut_DeadBandMode == PWM_ServoGaucheHaut__B_PWM__DBM_2_4_CLOCKS)
                    PWM_ServoGaucheHaut_WriteDeadTime(PWM_ServoGaucheHaut_backup.PWMdeadBandValue);
                #endif /* deadband count is either 2-4 clocks or 256 clocks */
            
                #if ( PWM_ServoGaucheHaut_KillModeMinTime)
                    PWM_ServoGaucheHaut_WriteKillTime(PWM_ServoGaucheHaut_backup.PWMKillCounterPeriod);
                #endif /* ( PWM_ServoGaucheHaut_KillModeMinTime) */
            #endif /* (CY_UDB_V0) */
            
            #if (CY_UDB_V1)
                #if(!PWM_ServoGaucheHaut_PWMModeIsCenterAligned)
                    PWM_ServoGaucheHaut_WritePeriod(PWM_ServoGaucheHaut_backup.PWMPeriod);
                #endif /* (!PWM_ServoGaucheHaut_PWMModeIsCenterAligned) */
                PWM_ServoGaucheHaut_WriteCounter(PWM_ServoGaucheHaut_backup.PWMUdb);
                #if (PWM_ServoGaucheHaut_UseStatus)
                    PWM_ServoGaucheHaut_STATUS_MASK = PWM_ServoGaucheHaut_backup.InterruptMaskValue;
                #endif /* (PWM_ServoGaucheHaut_UseStatus) */
                
                #if(PWM_ServoGaucheHaut_DeadBandMode == PWM_ServoGaucheHaut__B_PWM__DBM_256_CLOCKS || \
                    PWM_ServoGaucheHaut_DeadBandMode == PWM_ServoGaucheHaut__B_PWM__DBM_2_4_CLOCKS)
                    PWM_ServoGaucheHaut_WriteDeadTime(PWM_ServoGaucheHaut_backup.PWMdeadBandValue);
                #endif /* deadband count is either 2-4 clocks or 256 clocks */
                
                #if(PWM_ServoGaucheHaut_KillModeMinTime)
                    PWM_ServoGaucheHaut_WriteKillTime(PWM_ServoGaucheHaut_backup.PWMKillCounterPeriod);
                #endif /* (PWM_ServoGaucheHaut_KillModeMinTime) */
            #endif /* (CY_UDB_V1) */
            
            #if(PWM_ServoGaucheHaut_UseControl)
                PWM_ServoGaucheHaut_WriteControlRegister(PWM_ServoGaucheHaut_backup.PWMControlRegister); 
            #endif /* (PWM_ServoGaucheHaut_UseControl) */
        #endif  /* (!PWM_ServoGaucheHaut_UsingFixedFunction) */
    }


/*******************************************************************************
* Function Name: PWM_ServoGaucheHaut_Sleep
********************************************************************************
* 
* Summary:
*  Disables block's operation and saves the user configuration. Should be called 
*  just prior to entering sleep.
*  
* Parameters:  
*  None
*
* Return: 
*  None
*
* Global variables:
*  PWM_ServoGaucheHaut_backup.PWMEnableState:  Is modified depending on the enable 
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void PWM_ServoGaucheHaut_Sleep(void) 
{
    #if(PWM_ServoGaucheHaut_UseControl)
        if(PWM_ServoGaucheHaut_CTRL_ENABLE == (PWM_ServoGaucheHaut_CONTROL & PWM_ServoGaucheHaut_CTRL_ENABLE))
        {
            /*Component is enabled */
            PWM_ServoGaucheHaut_backup.PWMEnableState = 1u;
        }
        else
        {
            /* Component is disabled */
            PWM_ServoGaucheHaut_backup.PWMEnableState = 0u;
        }
    #endif /* (PWM_ServoGaucheHaut_UseControl) */

    /* Stop component */
    PWM_ServoGaucheHaut_Stop();
    
    /* Save registers configuration */
    PWM_ServoGaucheHaut_SaveConfig();
}


/*******************************************************************************
* Function Name: PWM_ServoGaucheHaut_Wakeup
********************************************************************************
* 
* Summary:
*  Restores and enables the user configuration. Should be called just after 
*  awaking from sleep.
*  
* Parameters:  
*  None
*
* Return: 
*  None
*
* Global variables:
*  PWM_ServoGaucheHaut_backup.pwmEnable:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void PWM_ServoGaucheHaut_Wakeup(void) 
{
     /* Restore registers values */
    PWM_ServoGaucheHaut_RestoreConfig();
    
    if(PWM_ServoGaucheHaut_backup.PWMEnableState != 0u)
    {
        /* Enable component's operation */
        PWM_ServoGaucheHaut_Enable();
    } /* Do nothing if component's block was disabled before */
    
}


/* [] END OF FILE */
