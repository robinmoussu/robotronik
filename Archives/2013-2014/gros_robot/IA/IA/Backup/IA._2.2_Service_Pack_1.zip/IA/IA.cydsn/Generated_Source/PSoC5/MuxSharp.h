/*******************************************************************************
* File Name: MuxSharp.h
* Version 1.70
*
*  Description:
*    This file contains the constants and function prototypes for the Analog
*    Multiplexer User Module AMux.
*
*   Note:
*
********************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#if !defined(CY_AMUX_MuxSharp_H)
#define CY_AMUX_MuxSharp_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cyfitter_cfg.h"


/***************************************
*        Function Prototypes
***************************************/

void MuxSharp_Start(void);
# define MuxSharp_Init() MuxSharp_Start()
void MuxSharp_FastSelect(uint8 channel) ;
/* The Stop, Select, Connect, Disconnect and DisconnectAll functions are declared elsewhere */
/* void MuxSharp_Stop(void); */
/* void MuxSharp_Select(uint8 channel); */
/* void MuxSharp_Connect(uint8 channel); */
/* void MuxSharp_Disconnect(uint8 channel); */
/* void MuxSharp_DisconnectAll(void) */


/***************************************
*     Initial Parameter Constants
***************************************/

#define MuxSharp_CHANNELS  2
#define MuxSharp_MUXTYPE   1
#define MuxSharp_ATMOSTONE 0

/***************************************
*             API Constants
***************************************/

#define MuxSharp_NULL_CHANNEL  0xFFu
#define MuxSharp_MUX_SINGLE   1
#define MuxSharp_MUX_DIFF     2


/***************************************
*        Conditional Functions
***************************************/

#if MuxSharp_MUXTYPE == MuxSharp_MUX_SINGLE
#if !MuxSharp_ATMOSTONE
# define MuxSharp_Connect(channel) MuxSharp_Set(channel)
#endif
# define MuxSharp_Disconnect(channel) MuxSharp_Unset(channel)
#else
#if !MuxSharp_ATMOSTONE
void MuxSharp_Connect(uint8 channel) ;
#endif
void MuxSharp_Disconnect(uint8 channel) ;
#endif

#if MuxSharp_ATMOSTONE
# define MuxSharp_Stop() MuxSharp_DisconnectAll()
# define MuxSharp_Select(channel) MuxSharp_FastSelect(channel)
void MuxSharp_DisconnectAll(void) ;
#else
# define MuxSharp_Stop() MuxSharp_Start()
void MuxSharp_Select(uint8 channel) ;
# define MuxSharp_DisconnectAll() MuxSharp_Start()
#endif

#endif /* CY_AMUX_MuxSharp_H */


/* [] END OF FILE */
