/*******************************************************************************
* File Name: Verre_Present.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Verre_Present_H) /* Pins Verre_Present_H */
#define CY_PINS_Verre_Present_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Verre_Present_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v1_90 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Verre_Present__PORT == 15 && ((Verre_Present__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    Verre_Present_Write(uint8 value) ;
void    Verre_Present_SetDriveMode(uint8 mode) ;
uint8   Verre_Present_ReadDataReg(void) ;
uint8   Verre_Present_Read(void) ;
uint8   Verre_Present_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Verre_Present_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define Verre_Present_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define Verre_Present_DM_RES_UP          PIN_DM_RES_UP
#define Verre_Present_DM_RES_DWN         PIN_DM_RES_DWN
#define Verre_Present_DM_OD_LO           PIN_DM_OD_LO
#define Verre_Present_DM_OD_HI           PIN_DM_OD_HI
#define Verre_Present_DM_STRONG          PIN_DM_STRONG
#define Verre_Present_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define Verre_Present_MASK               Verre_Present__MASK
#define Verre_Present_SHIFT              Verre_Present__SHIFT
#define Verre_Present_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Verre_Present_PS                     (* (reg8 *) Verre_Present__PS)
/* Data Register */
#define Verre_Present_DR                     (* (reg8 *) Verre_Present__DR)
/* Port Number */
#define Verre_Present_PRT_NUM                (* (reg8 *) Verre_Present__PRT) 
/* Connect to Analog Globals */                                                  
#define Verre_Present_AG                     (* (reg8 *) Verre_Present__AG)                       
/* Analog MUX bux enable */
#define Verre_Present_AMUX                   (* (reg8 *) Verre_Present__AMUX) 
/* Bidirectional Enable */                                                        
#define Verre_Present_BIE                    (* (reg8 *) Verre_Present__BIE)
/* Bit-mask for Aliased Register Access */
#define Verre_Present_BIT_MASK               (* (reg8 *) Verre_Present__BIT_MASK)
/* Bypass Enable */
#define Verre_Present_BYP                    (* (reg8 *) Verre_Present__BYP)
/* Port wide control signals */                                                   
#define Verre_Present_CTL                    (* (reg8 *) Verre_Present__CTL)
/* Drive Modes */
#define Verre_Present_DM0                    (* (reg8 *) Verre_Present__DM0) 
#define Verre_Present_DM1                    (* (reg8 *) Verre_Present__DM1)
#define Verre_Present_DM2                    (* (reg8 *) Verre_Present__DM2) 
/* Input Buffer Disable Override */
#define Verre_Present_INP_DIS                (* (reg8 *) Verre_Present__INP_DIS)
/* LCD Common or Segment Drive */
#define Verre_Present_LCD_COM_SEG            (* (reg8 *) Verre_Present__LCD_COM_SEG)
/* Enable Segment LCD */
#define Verre_Present_LCD_EN                 (* (reg8 *) Verre_Present__LCD_EN)
/* Slew Rate Control */
#define Verre_Present_SLW                    (* (reg8 *) Verre_Present__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Verre_Present_PRTDSI__CAPS_SEL       (* (reg8 *) Verre_Present__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Verre_Present_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Verre_Present__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Verre_Present_PRTDSI__OE_SEL0        (* (reg8 *) Verre_Present__PRTDSI__OE_SEL0) 
#define Verre_Present_PRTDSI__OE_SEL1        (* (reg8 *) Verre_Present__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Verre_Present_PRTDSI__OUT_SEL0       (* (reg8 *) Verre_Present__PRTDSI__OUT_SEL0) 
#define Verre_Present_PRTDSI__OUT_SEL1       (* (reg8 *) Verre_Present__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Verre_Present_PRTDSI__SYNC_OUT       (* (reg8 *) Verre_Present__PRTDSI__SYNC_OUT) 


#if defined(Verre_Present__INTSTAT)  /* Interrupt Registers */

    #define Verre_Present_INTSTAT                (* (reg8 *) Verre_Present__INTSTAT)
    #define Verre_Present_SNAP                   (* (reg8 *) Verre_Present__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Verre_Present_H */


/* [] END OF FILE */
