/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#ifndef BUMPER_H
#define BUMPER_H

void bumperGaucheHandler(void);
void bumperDroitHandler(void);
void bumperGaucheFinHandler(void);
void bumperDroitFinHandler(void);

#endif //BUMPER_H
//[] END OF FILE
