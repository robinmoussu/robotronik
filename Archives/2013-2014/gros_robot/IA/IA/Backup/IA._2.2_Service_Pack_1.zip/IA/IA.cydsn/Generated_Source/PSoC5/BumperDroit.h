/*******************************************************************************
* File Name: BumperDroit.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_BumperDroit_H) /* Pins BumperDroit_H */
#define CY_PINS_BumperDroit_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "BumperDroit_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v1_90 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 BumperDroit__PORT == 15 && ((BumperDroit__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    BumperDroit_Write(uint8 value) ;
void    BumperDroit_SetDriveMode(uint8 mode) ;
uint8   BumperDroit_ReadDataReg(void) ;
uint8   BumperDroit_Read(void) ;
uint8   BumperDroit_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define BumperDroit_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define BumperDroit_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define BumperDroit_DM_RES_UP          PIN_DM_RES_UP
#define BumperDroit_DM_RES_DWN         PIN_DM_RES_DWN
#define BumperDroit_DM_OD_LO           PIN_DM_OD_LO
#define BumperDroit_DM_OD_HI           PIN_DM_OD_HI
#define BumperDroit_DM_STRONG          PIN_DM_STRONG
#define BumperDroit_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define BumperDroit_MASK               BumperDroit__MASK
#define BumperDroit_SHIFT              BumperDroit__SHIFT
#define BumperDroit_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define BumperDroit_PS                     (* (reg8 *) BumperDroit__PS)
/* Data Register */
#define BumperDroit_DR                     (* (reg8 *) BumperDroit__DR)
/* Port Number */
#define BumperDroit_PRT_NUM                (* (reg8 *) BumperDroit__PRT) 
/* Connect to Analog Globals */                                                  
#define BumperDroit_AG                     (* (reg8 *) BumperDroit__AG)                       
/* Analog MUX bux enable */
#define BumperDroit_AMUX                   (* (reg8 *) BumperDroit__AMUX) 
/* Bidirectional Enable */                                                        
#define BumperDroit_BIE                    (* (reg8 *) BumperDroit__BIE)
/* Bit-mask for Aliased Register Access */
#define BumperDroit_BIT_MASK               (* (reg8 *) BumperDroit__BIT_MASK)
/* Bypass Enable */
#define BumperDroit_BYP                    (* (reg8 *) BumperDroit__BYP)
/* Port wide control signals */                                                   
#define BumperDroit_CTL                    (* (reg8 *) BumperDroit__CTL)
/* Drive Modes */
#define BumperDroit_DM0                    (* (reg8 *) BumperDroit__DM0) 
#define BumperDroit_DM1                    (* (reg8 *) BumperDroit__DM1)
#define BumperDroit_DM2                    (* (reg8 *) BumperDroit__DM2) 
/* Input Buffer Disable Override */
#define BumperDroit_INP_DIS                (* (reg8 *) BumperDroit__INP_DIS)
/* LCD Common or Segment Drive */
#define BumperDroit_LCD_COM_SEG            (* (reg8 *) BumperDroit__LCD_COM_SEG)
/* Enable Segment LCD */
#define BumperDroit_LCD_EN                 (* (reg8 *) BumperDroit__LCD_EN)
/* Slew Rate Control */
#define BumperDroit_SLW                    (* (reg8 *) BumperDroit__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define BumperDroit_PRTDSI__CAPS_SEL       (* (reg8 *) BumperDroit__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define BumperDroit_PRTDSI__DBL_SYNC_IN    (* (reg8 *) BumperDroit__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define BumperDroit_PRTDSI__OE_SEL0        (* (reg8 *) BumperDroit__PRTDSI__OE_SEL0) 
#define BumperDroit_PRTDSI__OE_SEL1        (* (reg8 *) BumperDroit__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define BumperDroit_PRTDSI__OUT_SEL0       (* (reg8 *) BumperDroit__PRTDSI__OUT_SEL0) 
#define BumperDroit_PRTDSI__OUT_SEL1       (* (reg8 *) BumperDroit__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define BumperDroit_PRTDSI__SYNC_OUT       (* (reg8 *) BumperDroit__PRTDSI__SYNC_OUT) 


#if defined(BumperDroit__INTSTAT)  /* Interrupt Registers */

    #define BumperDroit_INTSTAT                (* (reg8 *) BumperDroit__INTSTAT)
    #define BumperDroit_SNAP                   (* (reg8 *) BumperDroit__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_BumperDroit_H */


/* [] END OF FILE */
