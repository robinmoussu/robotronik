/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef CALLAGE_H
#define CALLAGE_H

#define RAD_TO_DEG (180.0/3.14159265359)

void callageDepart(void);

#endif
//[] END OF FILE
