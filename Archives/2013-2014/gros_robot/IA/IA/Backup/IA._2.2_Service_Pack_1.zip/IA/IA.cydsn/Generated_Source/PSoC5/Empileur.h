/*******************************************************************************
* File Name: Empileur.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Empileur_H) /* Pins Empileur_H */
#define CY_PINS_Empileur_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Empileur_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v1_90 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Empileur__PORT == 15 && ((Empileur__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    Empileur_Write(uint8 value) ;
void    Empileur_SetDriveMode(uint8 mode) ;
uint8   Empileur_ReadDataReg(void) ;
uint8   Empileur_Read(void) ;
uint8   Empileur_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Empileur_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define Empileur_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define Empileur_DM_RES_UP          PIN_DM_RES_UP
#define Empileur_DM_RES_DWN         PIN_DM_RES_DWN
#define Empileur_DM_OD_LO           PIN_DM_OD_LO
#define Empileur_DM_OD_HI           PIN_DM_OD_HI
#define Empileur_DM_STRONG          PIN_DM_STRONG
#define Empileur_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define Empileur_MASK               Empileur__MASK
#define Empileur_SHIFT              Empileur__SHIFT
#define Empileur_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Empileur_PS                     (* (reg8 *) Empileur__PS)
/* Data Register */
#define Empileur_DR                     (* (reg8 *) Empileur__DR)
/* Port Number */
#define Empileur_PRT_NUM                (* (reg8 *) Empileur__PRT) 
/* Connect to Analog Globals */                                                  
#define Empileur_AG                     (* (reg8 *) Empileur__AG)                       
/* Analog MUX bux enable */
#define Empileur_AMUX                   (* (reg8 *) Empileur__AMUX) 
/* Bidirectional Enable */                                                        
#define Empileur_BIE                    (* (reg8 *) Empileur__BIE)
/* Bit-mask for Aliased Register Access */
#define Empileur_BIT_MASK               (* (reg8 *) Empileur__BIT_MASK)
/* Bypass Enable */
#define Empileur_BYP                    (* (reg8 *) Empileur__BYP)
/* Port wide control signals */                                                   
#define Empileur_CTL                    (* (reg8 *) Empileur__CTL)
/* Drive Modes */
#define Empileur_DM0                    (* (reg8 *) Empileur__DM0) 
#define Empileur_DM1                    (* (reg8 *) Empileur__DM1)
#define Empileur_DM2                    (* (reg8 *) Empileur__DM2) 
/* Input Buffer Disable Override */
#define Empileur_INP_DIS                (* (reg8 *) Empileur__INP_DIS)
/* LCD Common or Segment Drive */
#define Empileur_LCD_COM_SEG            (* (reg8 *) Empileur__LCD_COM_SEG)
/* Enable Segment LCD */
#define Empileur_LCD_EN                 (* (reg8 *) Empileur__LCD_EN)
/* Slew Rate Control */
#define Empileur_SLW                    (* (reg8 *) Empileur__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Empileur_PRTDSI__CAPS_SEL       (* (reg8 *) Empileur__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Empileur_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Empileur__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Empileur_PRTDSI__OE_SEL0        (* (reg8 *) Empileur__PRTDSI__OE_SEL0) 
#define Empileur_PRTDSI__OE_SEL1        (* (reg8 *) Empileur__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Empileur_PRTDSI__OUT_SEL0       (* (reg8 *) Empileur__PRTDSI__OUT_SEL0) 
#define Empileur_PRTDSI__OUT_SEL1       (* (reg8 *) Empileur__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Empileur_PRTDSI__SYNC_OUT       (* (reg8 *) Empileur__PRTDSI__SYNC_OUT) 


#if defined(Empileur__INTSTAT)  /* Interrupt Registers */

    #define Empileur_INTSTAT                (* (reg8 *) Empileur__INTSTAT)
    #define Empileur_SNAP                   (* (reg8 *) Empileur__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Empileur_H */


/* [] END OF FILE */
