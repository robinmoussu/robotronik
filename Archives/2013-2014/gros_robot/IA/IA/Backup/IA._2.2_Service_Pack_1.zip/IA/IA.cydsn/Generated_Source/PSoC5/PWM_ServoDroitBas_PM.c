/*******************************************************************************
* File Name: PWM_ServoDroitBas_PM.c
* Version 2.40
*
* Description:
*  This file provides the power management source code to API for the
*  PWM.
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/
#include "cytypes.h"
#include "PWM_ServoDroitBas.h"

static PWM_ServoDroitBas_backupStruct PWM_ServoDroitBas_backup;


/*******************************************************************************
* Function Name: PWM_ServoDroitBas_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration of the component.
*  
* Parameters:  
*  None
*
* Return: 
*  None
*
* Global variables:
*  PWM_ServoDroitBas_backup:  Variables of this global structure are modified to 
*  store the values of non retention configuration registers when Sleep() API is 
*  called.
*
*******************************************************************************/
void PWM_ServoDroitBas_SaveConfig(void) 
{
    
    #if(!PWM_ServoDroitBas_UsingFixedFunction)
        #if (CY_UDB_V0)
            PWM_ServoDroitBas_backup.PWMUdb = PWM_ServoDroitBas_ReadCounter();
            PWM_ServoDroitBas_backup.PWMPeriod = PWM_ServoDroitBas_ReadPeriod();
            #if (PWM_ServoDroitBas_UseStatus)
                PWM_ServoDroitBas_backup.InterruptMaskValue = PWM_ServoDroitBas_STATUS_MASK;
            #endif /* (PWM_ServoDroitBas_UseStatus) */
            
            #if(PWM_ServoDroitBas_UseOneCompareMode)
                PWM_ServoDroitBas_backup.PWMCompareValue = PWM_ServoDroitBas_ReadCompare();
            #else
                PWM_ServoDroitBas_backup.PWMCompareValue1 = PWM_ServoDroitBas_ReadCompare1();
                PWM_ServoDroitBas_backup.PWMCompareValue2 = PWM_ServoDroitBas_ReadCompare2();
            #endif /* (PWM_ServoDroitBas_UseOneCompareMode) */
            
           #if(PWM_ServoDroitBas_DeadBandUsed)
                PWM_ServoDroitBas_backup.PWMdeadBandValue = PWM_ServoDroitBas_ReadDeadTime();
            #endif /* (PWM_ServoDroitBas_DeadBandUsed) */
          
            #if ( PWM_ServoDroitBas_KillModeMinTime)
                PWM_ServoDroitBas_backup.PWMKillCounterPeriod = PWM_ServoDroitBas_ReadKillTime();
            #endif /* ( PWM_ServoDroitBas_KillModeMinTime) */
        #endif /* (CY_UDB_V0) */
        
        #if (CY_UDB_V1)
            #if(!PWM_ServoDroitBas_PWMModeIsCenterAligned)
                PWM_ServoDroitBas_backup.PWMPeriod = PWM_ServoDroitBas_ReadPeriod();
            #endif /* (!PWM_ServoDroitBas_PWMModeIsCenterAligned) */
            PWM_ServoDroitBas_backup.PWMUdb = PWM_ServoDroitBas_ReadCounter();
            #if (PWM_ServoDroitBas_UseStatus)
                PWM_ServoDroitBas_backup.InterruptMaskValue = PWM_ServoDroitBas_STATUS_MASK;
            #endif /* (PWM_ServoDroitBas_UseStatus) */
            
            #if(PWM_ServoDroitBas_DeadBandMode == PWM_ServoDroitBas__B_PWM__DBM_256_CLOCKS || \
                PWM_ServoDroitBas_DeadBandMode == PWM_ServoDroitBas__B_PWM__DBM_2_4_CLOCKS)
                PWM_ServoDroitBas_backup.PWMdeadBandValue = PWM_ServoDroitBas_ReadDeadTime();
            #endif /*  deadband count is either 2-4 clocks or 256 clocks */
            
            #if(PWM_ServoDroitBas_KillModeMinTime)
                 PWM_ServoDroitBas_backup.PWMKillCounterPeriod = PWM_ServoDroitBas_ReadKillTime();
            #endif /* (PWM_ServoDroitBas_KillModeMinTime) */
        #endif /* (CY_UDB_V1) */
        
        #if(PWM_ServoDroitBas_UseControl)
            PWM_ServoDroitBas_backup.PWMControlRegister = PWM_ServoDroitBas_ReadControlRegister();
        #endif /* (PWM_ServoDroitBas_UseControl) */
    #endif  /* (!PWM_ServoDroitBas_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: PWM_ServoDroitBas_RestoreConfig
********************************************************************************
* 
* Summary:
*  Restores the current user configuration of the component.
*
* Parameters:  
*  None
*
* Return: 
*  None
*
* Global variables:
*  PWM_ServoDroitBas_backup:  Variables of this global structure are used to  
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void PWM_ServoDroitBas_RestoreConfig(void) 
{
        #if(!PWM_ServoDroitBas_UsingFixedFunction)
            #if (CY_UDB_V0)
                /* Interrupt State Backup for Critical Region*/
                uint8 PWM_ServoDroitBas_interruptState;
                /* Enter Critical Region*/
                PWM_ServoDroitBas_interruptState = CyEnterCriticalSection();
                #if (PWM_ServoDroitBas_UseStatus)
                    /* Use the interrupt output of the status register for IRQ output */
                    PWM_ServoDroitBas_STATUS_AUX_CTRL |= PWM_ServoDroitBas_STATUS_ACTL_INT_EN_MASK;
                    
                    PWM_ServoDroitBas_STATUS_MASK = PWM_ServoDroitBas_backup.InterruptMaskValue;
                #endif /* (PWM_ServoDroitBas_UseStatus) */
                
                #if (PWM_ServoDroitBas_Resolution == 8)
                    /* Set FIFO 0 to 1 byte register for period*/
                    PWM_ServoDroitBas_AUX_CONTROLDP0 |= (PWM_ServoDroitBas_AUX_CTRL_FIFO0_CLR);
                #else /* (PWM_ServoDroitBas_Resolution == 16)*/
                    /* Set FIFO 0 to 1 byte register for period */
                    PWM_ServoDroitBas_AUX_CONTROLDP0 |= (PWM_ServoDroitBas_AUX_CTRL_FIFO0_CLR);
                    PWM_ServoDroitBas_AUX_CONTROLDP1 |= (PWM_ServoDroitBas_AUX_CTRL_FIFO0_CLR);
                #endif /* (PWM_ServoDroitBas_Resolution == 8) */
                /* Exit Critical Region*/
                CyExitCriticalSection(PWM_ServoDroitBas_interruptState);
                
                PWM_ServoDroitBas_WriteCounter(PWM_ServoDroitBas_backup.PWMUdb);
                PWM_ServoDroitBas_WritePeriod(PWM_ServoDroitBas_backup.PWMPeriod);
                
                #if(PWM_ServoDroitBas_UseOneCompareMode)
                    PWM_ServoDroitBas_WriteCompare(PWM_ServoDroitBas_backup.PWMCompareValue);
                #else
                    PWM_ServoDroitBas_WriteCompare1(PWM_ServoDroitBas_backup.PWMCompareValue1);
                    PWM_ServoDroitBas_WriteCompare2(PWM_ServoDroitBas_backup.PWMCompareValue2);
                #endif /* (PWM_ServoDroitBas_UseOneCompareMode) */
                
               #if(PWM_ServoDroitBas_DeadBandMode == PWM_ServoDroitBas__B_PWM__DBM_256_CLOCKS || \
                   PWM_ServoDroitBas_DeadBandMode == PWM_ServoDroitBas__B_PWM__DBM_2_4_CLOCKS)
                    PWM_ServoDroitBas_WriteDeadTime(PWM_ServoDroitBas_backup.PWMdeadBandValue);
                #endif /* deadband count is either 2-4 clocks or 256 clocks */
            
                #if ( PWM_ServoDroitBas_KillModeMinTime)
                    PWM_ServoDroitBas_WriteKillTime(PWM_ServoDroitBas_backup.PWMKillCounterPeriod);
                #endif /* ( PWM_ServoDroitBas_KillModeMinTime) */
            #endif /* (CY_UDB_V0) */
            
            #if (CY_UDB_V1)
                #if(!PWM_ServoDroitBas_PWMModeIsCenterAligned)
                    PWM_ServoDroitBas_WritePeriod(PWM_ServoDroitBas_backup.PWMPeriod);
                #endif /* (!PWM_ServoDroitBas_PWMModeIsCenterAligned) */
                PWM_ServoDroitBas_WriteCounter(PWM_ServoDroitBas_backup.PWMUdb);
                #if (PWM_ServoDroitBas_UseStatus)
                    PWM_ServoDroitBas_STATUS_MASK = PWM_ServoDroitBas_backup.InterruptMaskValue;
                #endif /* (PWM_ServoDroitBas_UseStatus) */
                
                #if(PWM_ServoDroitBas_DeadBandMode == PWM_ServoDroitBas__B_PWM__DBM_256_CLOCKS || \
                    PWM_ServoDroitBas_DeadBandMode == PWM_ServoDroitBas__B_PWM__DBM_2_4_CLOCKS)
                    PWM_ServoDroitBas_WriteDeadTime(PWM_ServoDroitBas_backup.PWMdeadBandValue);
                #endif /* deadband count is either 2-4 clocks or 256 clocks */
                
                #if(PWM_ServoDroitBas_KillModeMinTime)
                    PWM_ServoDroitBas_WriteKillTime(PWM_ServoDroitBas_backup.PWMKillCounterPeriod);
                #endif /* (PWM_ServoDroitBas_KillModeMinTime) */
            #endif /* (CY_UDB_V1) */
            
            #if(PWM_ServoDroitBas_UseControl)
                PWM_ServoDroitBas_WriteControlRegister(PWM_ServoDroitBas_backup.PWMControlRegister); 
            #endif /* (PWM_ServoDroitBas_UseControl) */
        #endif  /* (!PWM_ServoDroitBas_UsingFixedFunction) */
    }


/*******************************************************************************
* Function Name: PWM_ServoDroitBas_Sleep
********************************************************************************
* 
* Summary:
*  Disables block's operation and saves the user configuration. Should be called 
*  just prior to entering sleep.
*  
* Parameters:  
*  None
*
* Return: 
*  None
*
* Global variables:
*  PWM_ServoDroitBas_backup.PWMEnableState:  Is modified depending on the enable 
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void PWM_ServoDroitBas_Sleep(void) 
{
    #if(PWM_ServoDroitBas_UseControl)
        if(PWM_ServoDroitBas_CTRL_ENABLE == (PWM_ServoDroitBas_CONTROL & PWM_ServoDroitBas_CTRL_ENABLE))
        {
            /*Component is enabled */
            PWM_ServoDroitBas_backup.PWMEnableState = 1u;
        }
        else
        {
            /* Component is disabled */
            PWM_ServoDroitBas_backup.PWMEnableState = 0u;
        }
    #endif /* (PWM_ServoDroitBas_UseControl) */

    /* Stop component */
    PWM_ServoDroitBas_Stop();
    
    /* Save registers configuration */
    PWM_ServoDroitBas_SaveConfig();
}


/*******************************************************************************
* Function Name: PWM_ServoDroitBas_Wakeup
********************************************************************************
* 
* Summary:
*  Restores and enables the user configuration. Should be called just after 
*  awaking from sleep.
*  
* Parameters:  
*  None
*
* Return: 
*  None
*
* Global variables:
*  PWM_ServoDroitBas_backup.pwmEnable:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void PWM_ServoDroitBas_Wakeup(void) 
{
     /* Restore registers values */
    PWM_ServoDroitBas_RestoreConfig();
    
    if(PWM_ServoDroitBas_backup.PWMEnableState != 0u)
    {
        /* Enable component's operation */
        PWM_ServoDroitBas_Enable();
    } /* Do nothing if component's block was disabled before */
    
}


/* [] END OF FILE */
