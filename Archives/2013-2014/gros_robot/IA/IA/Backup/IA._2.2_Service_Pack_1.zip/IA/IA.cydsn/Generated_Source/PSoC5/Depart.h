/*******************************************************************************
* File Name: Depart.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Depart_H) /* Pins Depart_H */
#define CY_PINS_Depart_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Depart_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v1_90 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Depart__PORT == 15 && ((Depart__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    Depart_Write(uint8 value) ;
void    Depart_SetDriveMode(uint8 mode) ;
uint8   Depart_ReadDataReg(void) ;
uint8   Depart_Read(void) ;
uint8   Depart_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Depart_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define Depart_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define Depart_DM_RES_UP          PIN_DM_RES_UP
#define Depart_DM_RES_DWN         PIN_DM_RES_DWN
#define Depart_DM_OD_LO           PIN_DM_OD_LO
#define Depart_DM_OD_HI           PIN_DM_OD_HI
#define Depart_DM_STRONG          PIN_DM_STRONG
#define Depart_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define Depart_MASK               Depart__MASK
#define Depart_SHIFT              Depart__SHIFT
#define Depart_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Depart_PS                     (* (reg8 *) Depart__PS)
/* Data Register */
#define Depart_DR                     (* (reg8 *) Depart__DR)
/* Port Number */
#define Depart_PRT_NUM                (* (reg8 *) Depart__PRT) 
/* Connect to Analog Globals */                                                  
#define Depart_AG                     (* (reg8 *) Depart__AG)                       
/* Analog MUX bux enable */
#define Depart_AMUX                   (* (reg8 *) Depart__AMUX) 
/* Bidirectional Enable */                                                        
#define Depart_BIE                    (* (reg8 *) Depart__BIE)
/* Bit-mask for Aliased Register Access */
#define Depart_BIT_MASK               (* (reg8 *) Depart__BIT_MASK)
/* Bypass Enable */
#define Depart_BYP                    (* (reg8 *) Depart__BYP)
/* Port wide control signals */                                                   
#define Depart_CTL                    (* (reg8 *) Depart__CTL)
/* Drive Modes */
#define Depart_DM0                    (* (reg8 *) Depart__DM0) 
#define Depart_DM1                    (* (reg8 *) Depart__DM1)
#define Depart_DM2                    (* (reg8 *) Depart__DM2) 
/* Input Buffer Disable Override */
#define Depart_INP_DIS                (* (reg8 *) Depart__INP_DIS)
/* LCD Common or Segment Drive */
#define Depart_LCD_COM_SEG            (* (reg8 *) Depart__LCD_COM_SEG)
/* Enable Segment LCD */
#define Depart_LCD_EN                 (* (reg8 *) Depart__LCD_EN)
/* Slew Rate Control */
#define Depart_SLW                    (* (reg8 *) Depart__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Depart_PRTDSI__CAPS_SEL       (* (reg8 *) Depart__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Depart_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Depart__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Depart_PRTDSI__OE_SEL0        (* (reg8 *) Depart__PRTDSI__OE_SEL0) 
#define Depart_PRTDSI__OE_SEL1        (* (reg8 *) Depart__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Depart_PRTDSI__OUT_SEL0       (* (reg8 *) Depart__PRTDSI__OUT_SEL0) 
#define Depart_PRTDSI__OUT_SEL1       (* (reg8 *) Depart__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Depart_PRTDSI__SYNC_OUT       (* (reg8 *) Depart__PRTDSI__SYNC_OUT) 


#if defined(Depart__INTSTAT)  /* Interrupt Registers */

    #define Depart_INTSTAT                (* (reg8 *) Depart__INTSTAT)
    #define Depart_SNAP                   (* (reg8 *) Depart__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Depart_H */


/* [] END OF FILE */
