/*******************************************************************************
* File Name: intSharp.h
* Version 1.60
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/
#if !defined(__intSharp_INTC_H__)
#define __intSharp_INTC_H__


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void intSharp_Start(void);
void intSharp_StartEx(cyisraddress address);
void intSharp_Stop(void) ;

CY_ISR_PROTO(intSharp_Interrupt);

void intSharp_SetVector(cyisraddress address) ;
cyisraddress intSharp_GetVector(void) ;

void intSharp_SetPriority(uint8 priority) ;
uint8 intSharp_GetPriority(void) ;

void intSharp_Enable(void) ;
uint8 intSharp_GetState(void) ;
void intSharp_Disable(void) ;

void intSharp_SetPending(void) ;
void intSharp_ClearPending(void) ;


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the intSharp ISR. */
#define intSharp_INTC_VECTOR            ((reg32 *) intSharp__INTC_VECT)

/* Address of the intSharp ISR priority. */
#define intSharp_INTC_PRIOR             ((reg8 *) intSharp__INTC_PRIOR_REG)

/* Priority of the intSharp interrupt. */
#define intSharp_INTC_PRIOR_NUMBER      intSharp__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable intSharp interrupt. */
#define intSharp_INTC_SET_EN            ((reg32 *) intSharp__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the intSharp interrupt. */
#define intSharp_INTC_CLR_EN            ((reg32 *) intSharp__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the intSharp interrupt state to pending. */
#define intSharp_INTC_SET_PD            ((reg32 *) intSharp__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the intSharp interrupt. */
#define intSharp_INTC_CLR_PD            ((reg32 *) intSharp__INTC_CLR_PD_REG)



/* __intSharp_INTC_H__ */
#endif
