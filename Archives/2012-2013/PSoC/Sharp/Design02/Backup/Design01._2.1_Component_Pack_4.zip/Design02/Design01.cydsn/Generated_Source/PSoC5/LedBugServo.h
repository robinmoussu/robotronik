/*******************************************************************************
* File Name: LedBugServo.h  
* Version 1.70
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#if !defined(CY_PINS_LedBugServo_H) /* Pins LedBugServo_H */
#define CY_PINS_LedBugServo_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "LedBugServo_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v1_70 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 LedBugServo__PORT == 15 && (LedBugServo__MASK & 0xC0))

/***************************************
*        Function Prototypes             
***************************************/    

void    LedBugServo_Write(uint8 value) ;
void    LedBugServo_SetDriveMode(uint8 mode) ;
uint8   LedBugServo_ReadDataReg(void) ;
uint8   LedBugServo_Read(void) ;
uint8   LedBugServo_ClearInterrupt(void) ;

/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define LedBugServo_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define LedBugServo_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define LedBugServo_DM_RES_UP          PIN_DM_RES_UP
#define LedBugServo_DM_RES_DWN         PIN_DM_RES_DWN
#define LedBugServo_DM_OD_LO           PIN_DM_OD_LO
#define LedBugServo_DM_OD_HI           PIN_DM_OD_HI
#define LedBugServo_DM_STRONG          PIN_DM_STRONG
#define LedBugServo_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define LedBugServo_MASK               LedBugServo__MASK
#define LedBugServo_SHIFT              LedBugServo__SHIFT
#define LedBugServo_WIDTH              1u

/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define LedBugServo_PS                     (* (reg8 *) LedBugServo__PS)
/* Data Register */
#define LedBugServo_DR                     (* (reg8 *) LedBugServo__DR)
/* Port Number */
#define LedBugServo_PRT_NUM                (* (reg8 *) LedBugServo__PRT) 
/* Connect to Analog Globals */                                                  
#define LedBugServo_AG                     (* (reg8 *) LedBugServo__AG)                       
/* Analog MUX bux enable */
#define LedBugServo_AMUX                   (* (reg8 *) LedBugServo__AMUX) 
/* Bidirectional Enable */                                                        
#define LedBugServo_BIE                    (* (reg8 *) LedBugServo__BIE)
/* Bit-mask for Aliased Register Access */
#define LedBugServo_BIT_MASK               (* (reg8 *) LedBugServo__BIT_MASK)
/* Bypass Enable */
#define LedBugServo_BYP                    (* (reg8 *) LedBugServo__BYP)
/* Port wide control signals */                                                   
#define LedBugServo_CTL                    (* (reg8 *) LedBugServo__CTL)
/* Drive Modes */
#define LedBugServo_DM0                    (* (reg8 *) LedBugServo__DM0) 
#define LedBugServo_DM1                    (* (reg8 *) LedBugServo__DM1)
#define LedBugServo_DM2                    (* (reg8 *) LedBugServo__DM2) 
/* Input Buffer Disable Override */
#define LedBugServo_INP_DIS                (* (reg8 *) LedBugServo__INP_DIS)
/* LCD Common or Segment Drive */
#define LedBugServo_LCD_COM_SEG            (* (reg8 *) LedBugServo__LCD_COM_SEG)
/* Enable Segment LCD */
#define LedBugServo_LCD_EN                 (* (reg8 *) LedBugServo__LCD_EN)
/* Slew Rate Control */
#define LedBugServo_SLW                    (* (reg8 *) LedBugServo__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define LedBugServo_PRTDSI__CAPS_SEL       (* (reg8 *) LedBugServo__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define LedBugServo_PRTDSI__DBL_SYNC_IN    (* (reg8 *) LedBugServo__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define LedBugServo_PRTDSI__OE_SEL0        (* (reg8 *) LedBugServo__PRTDSI__OE_SEL0) 
#define LedBugServo_PRTDSI__OE_SEL1        (* (reg8 *) LedBugServo__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define LedBugServo_PRTDSI__OUT_SEL0       (* (reg8 *) LedBugServo__PRTDSI__OUT_SEL0) 
#define LedBugServo_PRTDSI__OUT_SEL1       (* (reg8 *) LedBugServo__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define LedBugServo_PRTDSI__SYNC_OUT       (* (reg8 *) LedBugServo__PRTDSI__SYNC_OUT) 


#if defined(LedBugServo__INTSTAT)  /* Interrupt Registers */

    #define LedBugServo_INTSTAT                (* (reg8 *) LedBugServo__INTSTAT)
    #define LedBugServo_SNAP                   (* (reg8 *) LedBugServo__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins LedBugServo_H */

#endif
/* [] END OF FILE */
