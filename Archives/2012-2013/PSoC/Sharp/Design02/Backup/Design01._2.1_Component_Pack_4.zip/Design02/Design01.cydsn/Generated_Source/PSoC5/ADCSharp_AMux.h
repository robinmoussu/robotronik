/*******************************************************************************
* File Name: ADCSharp_AMux.h
* Version 1.60
*
*  Description:
*    This file contains the constants and function prototypes for the Analog
*    Multiplexer User Module AMux.
*
*   Note:
*
********************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#if !defined(CY_AMUX_ADCSharp_AMux_H)
#define CY_AMUX_ADCSharp_AMux_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cyfitter_cfg.h"


/***************************************
*        Function Prototypes
***************************************/

void ADCSharp_AMux_Start(void);
# define ADCSharp_AMux_Init() ADCSharp_AMux_Start()
void ADCSharp_AMux_FastSelect(uint8 channel) ;
/* The Stop, Select, Connect, Disconnect and DisconnectAll functions are declared elsewhere */
/* void ADCSharp_AMux_Stop(void); */
/* void ADCSharp_AMux_Select(uint8 channel); */
/* void ADCSharp_AMux_Connect(uint8 channel); */
/* void ADCSharp_AMux_Disconnect(uint8 channel); */
/* void ADCSharp_AMux_DisconnectAll(void) */


/***************************************
*     Initial Parameter Constants
***************************************/

#define ADCSharp_AMux_CHANNELS  2
#define ADCSharp_AMux_MUXTYPE   1
#define ADCSharp_AMux_ATMOSTONE 0

/***************************************
*             API Constants
***************************************/

#define ADCSharp_AMux_NULL_CHANNEL  0xFFu
#define ADCSharp_AMux_MUX_SINGLE   1
#define ADCSharp_AMux_MUX_DIFF     2


/***************************************
*        Conditional Functions
***************************************/

#if ADCSharp_AMux_MUXTYPE == ADCSharp_AMux_MUX_SINGLE
#if !ADCSharp_AMux_ATMOSTONE
# define ADCSharp_AMux_Connect(channel) ADCSharp_AMux_Set(channel)
#endif
# define ADCSharp_AMux_Disconnect(channel) ADCSharp_AMux_Unset(channel)
#else
#if !ADCSharp_AMux_ATMOSTONE
void ADCSharp_AMux_Connect(uint8 channel) ;
#endif
void ADCSharp_AMux_Disconnect(uint8 channel) ;
#endif

#if ADCSharp_AMux_ATMOSTONE
# define ADCSharp_AMux_Stop() ADCSharp_AMux_DisconnectAll()
# define ADCSharp_AMux_Select(channel) ADCSharp_AMux_FastSelect(channel)
void ADCSharp_AMux_DisconnectAll(void) ;
#else
# define ADCSharp_AMux_Stop() ADCSharp_AMux_Start()
void ADCSharp_AMux_Select(uint8 channel) ;
# define ADCSharp_AMux_DisconnectAll() ADCSharp_AMux_Start()
#endif

#endif /* CY_AMUX_ADCSharp_AMux_H */


/* [] END OF FILE */
