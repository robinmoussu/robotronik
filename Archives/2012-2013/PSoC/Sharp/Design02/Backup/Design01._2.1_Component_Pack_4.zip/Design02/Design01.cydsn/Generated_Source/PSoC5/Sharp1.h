/*******************************************************************************
* File Name: Sharp1.h  
* Version 1.70
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#if !defined(CY_PINS_Sharp1_H) /* Pins Sharp1_H */
#define CY_PINS_Sharp1_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Sharp1_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v1_70 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Sharp1__PORT == 15 && (Sharp1__MASK & 0xC0))

/***************************************
*        Function Prototypes             
***************************************/    

void    Sharp1_Write(uint8 value) ;
void    Sharp1_SetDriveMode(uint8 mode) ;
uint8   Sharp1_ReadDataReg(void) ;
uint8   Sharp1_Read(void) ;
uint8   Sharp1_ClearInterrupt(void) ;

/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Sharp1_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define Sharp1_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define Sharp1_DM_RES_UP          PIN_DM_RES_UP
#define Sharp1_DM_RES_DWN         PIN_DM_RES_DWN
#define Sharp1_DM_OD_LO           PIN_DM_OD_LO
#define Sharp1_DM_OD_HI           PIN_DM_OD_HI
#define Sharp1_DM_STRONG          PIN_DM_STRONG
#define Sharp1_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define Sharp1_MASK               Sharp1__MASK
#define Sharp1_SHIFT              Sharp1__SHIFT
#define Sharp1_WIDTH              1u

/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Sharp1_PS                     (* (reg8 *) Sharp1__PS)
/* Data Register */
#define Sharp1_DR                     (* (reg8 *) Sharp1__DR)
/* Port Number */
#define Sharp1_PRT_NUM                (* (reg8 *) Sharp1__PRT) 
/* Connect to Analog Globals */                                                  
#define Sharp1_AG                     (* (reg8 *) Sharp1__AG)                       
/* Analog MUX bux enable */
#define Sharp1_AMUX                   (* (reg8 *) Sharp1__AMUX) 
/* Bidirectional Enable */                                                        
#define Sharp1_BIE                    (* (reg8 *) Sharp1__BIE)
/* Bit-mask for Aliased Register Access */
#define Sharp1_BIT_MASK               (* (reg8 *) Sharp1__BIT_MASK)
/* Bypass Enable */
#define Sharp1_BYP                    (* (reg8 *) Sharp1__BYP)
/* Port wide control signals */                                                   
#define Sharp1_CTL                    (* (reg8 *) Sharp1__CTL)
/* Drive Modes */
#define Sharp1_DM0                    (* (reg8 *) Sharp1__DM0) 
#define Sharp1_DM1                    (* (reg8 *) Sharp1__DM1)
#define Sharp1_DM2                    (* (reg8 *) Sharp1__DM2) 
/* Input Buffer Disable Override */
#define Sharp1_INP_DIS                (* (reg8 *) Sharp1__INP_DIS)
/* LCD Common or Segment Drive */
#define Sharp1_LCD_COM_SEG            (* (reg8 *) Sharp1__LCD_COM_SEG)
/* Enable Segment LCD */
#define Sharp1_LCD_EN                 (* (reg8 *) Sharp1__LCD_EN)
/* Slew Rate Control */
#define Sharp1_SLW                    (* (reg8 *) Sharp1__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Sharp1_PRTDSI__CAPS_SEL       (* (reg8 *) Sharp1__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Sharp1_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Sharp1__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Sharp1_PRTDSI__OE_SEL0        (* (reg8 *) Sharp1__PRTDSI__OE_SEL0) 
#define Sharp1_PRTDSI__OE_SEL1        (* (reg8 *) Sharp1__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Sharp1_PRTDSI__OUT_SEL0       (* (reg8 *) Sharp1__PRTDSI__OUT_SEL0) 
#define Sharp1_PRTDSI__OUT_SEL1       (* (reg8 *) Sharp1__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Sharp1_PRTDSI__SYNC_OUT       (* (reg8 *) Sharp1__PRTDSI__SYNC_OUT) 


#if defined(Sharp1__INTSTAT)  /* Interrupt Registers */

    #define Sharp1_INTSTAT                (* (reg8 *) Sharp1__INTSTAT)
    #define Sharp1_SNAP                   (* (reg8 *) Sharp1__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins Sharp1_H */

#endif
/* [] END OF FILE */
