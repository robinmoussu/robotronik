/*******************************************************************************
* File Name: MuxSharp.c
* Version 1.60
*
*  Description:
*    This file contains all functions required for the analog multiplexer
*    AMux User Module.
*
*   Note:
*
*******************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#include "MuxSharp.h"

uint8 MuxSharp_lastChannel = MuxSharp_NULL_CHANNEL;


/*******************************************************************************
* Function Name: MuxSharp_Start
********************************************************************************
* Summary:
*  Disconnect all channels.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void MuxSharp_Start(void)
{
    uint8 chan;

    for(chan = 0; chan < MuxSharp_CHANNELS ; chan++)
    {
#if(MuxSharp_MUXTYPE == MuxSharp_MUX_SINGLE)
        MuxSharp_Unset(chan);
#else
        MuxSharp_CYAMUXSIDE_A_Unset(chan);
        MuxSharp_CYAMUXSIDE_B_Unset(chan);
#endif
    }

	MuxSharp_lastChannel = MuxSharp_NULL_CHANNEL;
}


#if(!MuxSharp_ATMOSTONE)
/*******************************************************************************
* Function Name: MuxSharp_Select
********************************************************************************
* Summary:
*  This functions first disconnects all channels then connects the given
*  channel.
*
* Parameters:
*  channel:  The channel to connect to the common terminal.
*
* Return:
*  void
*
*******************************************************************************/
void MuxSharp_Select(uint8 channel) 
{
    MuxSharp_DisconnectAll();        /* Disconnect all previous connections */
    MuxSharp_Connect(channel);       /* Make the given selection */
    MuxSharp_lastChannel = channel;  /* Update last channel */
}
#endif


/*******************************************************************************
* Function Name: MuxSharp_FastSelect
********************************************************************************
* Summary:
*  This function first disconnects the last connection made with FastSelect or
*  Select, then connects the given channel. The FastSelect function is similar
*  to the Select function, except it is faster since it only disconnects the
*  last channel selected rather than all channels.
*
* Parameters:
*  channel:  The channel to connect to the common terminal.
*
* Return:
*  void
*
*******************************************************************************/
void MuxSharp_FastSelect(uint8 channel) 
{
    /* Disconnect the last valid channel */
    if( MuxSharp_lastChannel != MuxSharp_NULL_CHANNEL)
    {
        MuxSharp_Disconnect(MuxSharp_lastChannel);
    }

    /* Make the new channel connection */
#if(MuxSharp_MUXTYPE == MuxSharp_MUX_SINGLE)
    MuxSharp_Set(channel);
#else
    MuxSharp_CYAMUXSIDE_A_Set(channel);
    MuxSharp_CYAMUXSIDE_B_Set(channel);
#endif


	MuxSharp_lastChannel = channel;   /* Update last channel */
}


#if(MuxSharp_MUXTYPE == MuxSharp_MUX_DIFF)
#if(!MuxSharp_ATMOSTONE)
/*******************************************************************************
* Function Name: MuxSharp_Connect
********************************************************************************
* Summary:
*  This function connects the given channel without affecting other connections.
*
* Parameters:
*  channel:  The channel to connect to the common terminal.
*
* Return:
*  void
*
*******************************************************************************/
void MuxSharp_Connect(uint8 channel) 
{
    MuxSharp_CYAMUXSIDE_A_Set(channel);
    MuxSharp_CYAMUXSIDE_B_Set(channel);
}
#endif

/*******************************************************************************
* Function Name: MuxSharp_Disconnect
********************************************************************************
* Summary:
*  This function disconnects the given channel from the common or output
*  terminal without affecting other connections.
*
* Parameters:
*  channel:  The channel to disconnect from the common terminal.
*
* Return:
*  void
*
*******************************************************************************/
void MuxSharp_Disconnect(uint8 channel) 
{
    MuxSharp_CYAMUXSIDE_A_Unset(channel);
    MuxSharp_CYAMUXSIDE_B_Unset(channel);
}
#endif

#if(MuxSharp_ATMOSTONE)
/*******************************************************************************
* Function Name: MuxSharp_DisconnectAll
********************************************************************************
* Summary:
*  This function disconnects all channels.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void MuxSharp_DisconnectAll(void) 
{
    if(MuxSharp_lastChannel != MuxSharp_NULL_CHANNEL) 
    {
        MuxSharp_Disconnect(MuxSharp_lastChannel);
		MuxSharp_lastChannel = MuxSharp_NULL_CHANNEL;
    }
}
#endif

/* [] END OF FILE */
