/*******************************************************************************
* File Name: PWMServoSharp.c  
* Version 2.20
*
* Description:
*  The PWM User Module consist of an 8 or 16-bit counter with two 8 or 16-bit
*  comparitors. Each instance of this user module is capable of generating
*  two PWM outputs with the same period. The pulse width is selectable between
*  1 and 255/65535. The period is selectable between 2 and 255/65536 clocks. 
*  The compare value output may be configured to be active when the present 
*  counter is less than or less than/equal to the compare value.
*  A terminal count output is also provided. It generates a pulse one clock
*  width wide when the counter is equal to zero.
*
* Note:
*
*******************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#include "cytypes.h"
#include "PWMServoSharp.h"

uint8 PWMServoSharp_initVar = 0u;


/*******************************************************************************
* Function Name: PWMServoSharp_Start
********************************************************************************
*
* Summary:
*  The start function initializes the pwm with the default values, the 
*  enables the counter to begin counting.  It does not enable interrupts,
*  the EnableInt command should be called if interrupt generation is required.
*
* Parameters:  
*  void  
*
* Return: 
*  void
*
* Global variables:
*  PWMServoSharp_initVar: Is modified when this function is called for the 
*   first time. Is used to ensure that initialization happens only once.
*
*******************************************************************************/
void PWMServoSharp_Start(void) 
{
    /* If not Initialized then initialize all required hardware and software */
    if(PWMServoSharp_initVar == 0u)
    {
        PWMServoSharp_Init();
        PWMServoSharp_initVar = 1u;
    }
    PWMServoSharp_Enable();

}


/*******************************************************************************
* Function Name: PWMServoSharp_Init
********************************************************************************
*
* Summary:
*  Initialize component's parameters to the parameters set by user in the 
*  customizer of the component placed onto schematic. Usually called in 
*  PWMServoSharp_Start().
*
* Parameters:  
*  void
*
* Return: 
*  void
*
*******************************************************************************/
void PWMServoSharp_Init(void) 
{
    #if (PWMServoSharp_UsingFixedFunction || PWMServoSharp_UseControl)
        uint8 ctrl;
    #endif /* (PWMServoSharp_UsingFixedFunction || PWMServoSharp_UseControl) */
    
    #if(!PWMServoSharp_UsingFixedFunction) 
        #if(PWMServoSharp_UseStatus)
            /* Interrupt State Backup for Critical Region*/
            uint8 PWMServoSharp_interruptState;
        #endif /* (PWMServoSharp_UseStatus) */
    #endif /* (!PWMServoSharp_UsingFixedFunction) */
    
    #if (PWMServoSharp_UsingFixedFunction)
        /* You are allowed to write the compare value (FF only) */
        PWMServoSharp_CONTROL |= PWMServoSharp_CFG0_MODE;
        #if (PWMServoSharp_DeadBand2_4)
            PWMServoSharp_CONTROL |= PWMServoSharp_CFG0_DB;
        #endif /* (PWMServoSharp_DeadBand2_4) */
                
        /* Set the default Compare Mode */
        #if(CY_PSOC5A)
                ctrl = PWMServoSharp_CONTROL2 & ~PWMServoSharp_CTRL_CMPMODE1_MASK;
                PWMServoSharp_CONTROL2 = ctrl | PWMServoSharp_DEFAULT_COMPARE1_MODE;
        #endif /* (CY_PSOC5A) */
        #if(CY_PSOC3 || CY_PSOC5LP)
                ctrl = PWMServoSharp_CONTROL3 & ~PWMServoSharp_CTRL_CMPMODE1_MASK;
                PWMServoSharp_CONTROL3 = ctrl | PWMServoSharp_DEFAULT_COMPARE1_MODE;
        #endif /* (CY_PSOC3 || CY_PSOC5LP) */
        
         /* Clear and Set SYNCTC and SYNCCMP bits of RT1 register */
        PWMServoSharp_RT1 &= ~PWMServoSharp_RT1_MASK;
        PWMServoSharp_RT1 |= PWMServoSharp_SYNC;     
                
        /*Enable DSI Sync all all inputs of the PWM*/
        PWMServoSharp_RT1 &= ~(PWMServoSharp_SYNCDSI_MASK);
        PWMServoSharp_RT1 |= PWMServoSharp_SYNCDSI_EN;
       
    #elif (PWMServoSharp_UseControl)
        /* Set the default compare mode defined in the parameter */
        ctrl = PWMServoSharp_CONTROL & ~PWMServoSharp_CTRL_CMPMODE2_MASK & ~PWMServoSharp_CTRL_CMPMODE1_MASK;
        PWMServoSharp_CONTROL = ctrl | PWMServoSharp_DEFAULT_COMPARE2_MODE | 
                                   PWMServoSharp_DEFAULT_COMPARE1_MODE;
    #endif /* (PWMServoSharp_UsingFixedFunction) */
        
    #if (!PWMServoSharp_UsingFixedFunction)
        #if (PWMServoSharp_Resolution == 8)
            /* Set FIFO 0 to 1 byte register for period*/
            PWMServoSharp_AUX_CONTROLDP0 |= (PWMServoSharp_AUX_CTRL_FIFO0_CLR);
        #else /* (PWMServoSharp_Resolution == 16)*/
            /* Set FIFO 0 to 1 byte register for period */
            PWMServoSharp_AUX_CONTROLDP0 |= (PWMServoSharp_AUX_CTRL_FIFO0_CLR);
            PWMServoSharp_AUX_CONTROLDP1 |= (PWMServoSharp_AUX_CTRL_FIFO0_CLR);
        #endif /* (PWMServoSharp_Resolution == 8) */

        PWMServoSharp_WriteCounter(PWMServoSharp_INIT_PERIOD_VALUE);
    #endif /* (!PWMServoSharp_UsingFixedFunction) */
        
    PWMServoSharp_WritePeriod(PWMServoSharp_INIT_PERIOD_VALUE);

        #if (PWMServoSharp_UseOneCompareMode)
            PWMServoSharp_WriteCompare(PWMServoSharp_INIT_COMPARE_VALUE1);
        #else
            PWMServoSharp_WriteCompare1(PWMServoSharp_INIT_COMPARE_VALUE1);
            PWMServoSharp_WriteCompare2(PWMServoSharp_INIT_COMPARE_VALUE2);
        #endif /* (PWMServoSharp_UseOneCompareMode) */
        
        #if (PWMServoSharp_KillModeMinTime)
            PWMServoSharp_WriteKillTime(PWMServoSharp_MinimumKillTime);
        #endif /* (PWMServoSharp_KillModeMinTime) */
        
        #if (PWMServoSharp_DeadBandUsed)
            PWMServoSharp_WriteDeadTime(PWMServoSharp_INIT_DEAD_TIME);
        #endif /* (PWMServoSharp_DeadBandUsed) */

    #if (PWMServoSharp_UseStatus || PWMServoSharp_UsingFixedFunction)
        PWMServoSharp_SetInterruptMode(PWMServoSharp_INIT_INTERRUPTS_MODE);
    #endif /* (PWMServoSharp_UseStatus || PWMServoSharp_UsingFixedFunction) */
        
    #if (PWMServoSharp_UsingFixedFunction)
        /* Globally Enable the Fixed Function Block chosen */
        PWMServoSharp_GLOBAL_ENABLE |= PWMServoSharp_BLOCK_EN_MASK;
        /* Set the Interrupt source to come from the status register */
        PWMServoSharp_CONTROL2 |= PWMServoSharp_CTRL2_IRQ_SEL;
    #else
        #if(PWMServoSharp_UseStatus)
            
            /* CyEnterCriticalRegion and CyExitCriticalRegion are used to mark following region critical*/
            /* Enter Critical Region*/
            PWMServoSharp_interruptState = CyEnterCriticalSection();
            /* Use the interrupt output of the status register for IRQ output */
            PWMServoSharp_STATUS_AUX_CTRL |= PWMServoSharp_STATUS_ACTL_INT_EN_MASK;
            
             /* Exit Critical Region*/
            CyExitCriticalSection(PWMServoSharp_interruptState);
            
            /* Clear the FIFO to enable the PWMServoSharp_STATUS_FIFOFULL
                   bit to be set on FIFO full. */
            PWMServoSharp_ClearFIFO();
        #endif /* (PWMServoSharp_UseStatus) */
    #endif /* (PWMServoSharp_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: PWMServoSharp_Enable
********************************************************************************
*
* Summary: 
*  Enables the PWM block operation
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Side Effects: 
*  This works only if software enable mode is chosen
*
*******************************************************************************/
void PWMServoSharp_Enable(void) 
{
    /* Globally Enable the Fixed Function Block chosen */
    #if (PWMServoSharp_UsingFixedFunction)
        PWMServoSharp_GLOBAL_ENABLE |= PWMServoSharp_BLOCK_EN_MASK;
        PWMServoSharp_GLOBAL_STBY_ENABLE |= PWMServoSharp_BLOCK_STBY_EN_MASK;
    #endif /* (PWMServoSharp_UsingFixedFunction) */
    
    /* Enable the PWM from the control register  */
    #if (PWMServoSharp_UseControl || PWMServoSharp_UsingFixedFunction)
        PWMServoSharp_CONTROL |= PWMServoSharp_CTRL_ENABLE;
    #endif /* (PWMServoSharp_UseControl || PWMServoSharp_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: PWMServoSharp_Stop
********************************************************************************
*
* Summary:
*  The stop function halts the PWM, but does not change any modes or disable
*  interrupts.
*
* Parameters:  
*  void  
*
* Return: 
*  void
*
* Side Effects:
*  If the Enable mode is set to Hardware only then this function
*  has no effect on the operation of the PWM
*
*******************************************************************************/
void PWMServoSharp_Stop(void) 
{
    #if (PWMServoSharp_UseControl || PWMServoSharp_UsingFixedFunction)
        PWMServoSharp_CONTROL &= ~PWMServoSharp_CTRL_ENABLE;
    #endif /* (PWMServoSharp_UseControl || PWMServoSharp_UsingFixedFunction) */
    
    /* Globally disable the Fixed Function Block chosen */
    #if (PWMServoSharp_UsingFixedFunction)
        PWMServoSharp_GLOBAL_ENABLE &= ~PWMServoSharp_BLOCK_EN_MASK;
        PWMServoSharp_GLOBAL_STBY_ENABLE &= ~PWMServoSharp_BLOCK_STBY_EN_MASK;
    #endif /* (PWMServoSharp_UsingFixedFunction) */
}


#if (PWMServoSharp_UseOneCompareMode)
#if (PWMServoSharp_CompareMode1SW)


/*******************************************************************************
* Function Name: PWMServoSharp_SetCompareMode
********************************************************************************
* 
* Summary:
*  This function writes the Compare Mode for the pwm output when in Dither mode,
*  Center Align Mode or One Output Mode.
*
* Parameters:
*  comparemode:  The new compare mode for the PWM output. Use the compare types
*                defined in the H file as input arguments.
*
* Return:
*  void
*
*******************************************************************************/
void PWMServoSharp_SetCompareMode(uint8 comparemode) 
{
    #if(PWMServoSharp_UsingFixedFunction)
        #if(CY_PSOC5A)
            uint8 comparemodemasked = (comparemode << PWMServoSharp_CTRL_CMPMODE1_SHIFT);
            PWMServoSharp_CONTROL2 &= ~PWMServoSharp_CTRL_CMPMODE1_MASK; /*Clear Existing Data */
            PWMServoSharp_CONTROL2 |= comparemodemasked;  
        #endif /* (CY_PSOC5A) */
                
        #if(CY_PSOC3 || CY_PSOC5LP)
            uint8 comparemodemasked = (comparemode << PWMServoSharp_CTRL_CMPMODE1_SHIFT);
            PWMServoSharp_CONTROL3 &= ~PWMServoSharp_CTRL_CMPMODE1_MASK; /*Clear Existing Data */
            PWMServoSharp_CONTROL3 |= comparemodemasked;     
        #endif /* (CY_PSOC3 || CY_PSOC5LP) */
                
    #elif (PWMServoSharp_UseControl)
        uint8 comparemode1masked = (comparemode << PWMServoSharp_CTRL_CMPMODE1_SHIFT) & 
                                    PWMServoSharp_CTRL_CMPMODE1_MASK;
        uint8 comparemode2masked = (comparemode << PWMServoSharp_CTRL_CMPMODE2_SHIFT) & 
                                   PWMServoSharp_CTRL_CMPMODE2_MASK;
        /*Clear existing mode */
        PWMServoSharp_CONTROL &= ~(PWMServoSharp_CTRL_CMPMODE1_MASK | PWMServoSharp_CTRL_CMPMODE2_MASK); 
        PWMServoSharp_CONTROL |= (comparemode1masked | comparemode2masked);
        
    #else
        uint8 temp = comparemode;
    #endif /* (PWMServoSharp_UsingFixedFunction) */
}
#endif /* PWMServoSharp_CompareMode1SW */

#else /* UseOneCompareMode */


#if (PWMServoSharp_CompareMode1SW)


/*******************************************************************************
* Function Name: PWMServoSharp_SetCompareMode1
********************************************************************************
* 
* Summary:
*  This function writes the Compare Mode for the pwm or pwm1 output
*
* Parameters:  
*  comparemode:  The new compare mode for the PWM output. Use the compare types
*                defined in the H file as input arguments.
*
* Return: 
*  void
*
*******************************************************************************/
void PWMServoSharp_SetCompareMode1(uint8 comparemode) 
{
    uint8 comparemodemasked = (comparemode << PWMServoSharp_CTRL_CMPMODE1_SHIFT) & 
                               PWMServoSharp_CTRL_CMPMODE1_MASK;
    #if(PWMServoSharp_UsingFixedFunction)
        #if(CY_PSOC5A)
            PWMServoSharp_CONTROL2 &= PWMServoSharp_CTRL_CMPMODE1_MASK; /*Clear existing mode */
            PWMServoSharp_CONTROL2 |= comparemodemasked; 
        #endif /* (CY_PSOC5A) */
                
        #if(CY_PSOC3 || CY_PSOC5LP)
            PWMServoSharp_CONTROL3 &= PWMServoSharp_CTRL_CMPMODE1_MASK; /*Clear existing mode */
            PWMServoSharp_CONTROL3 |= comparemodemasked; 
        #endif /* (CY_PSOC3 || CY_PSOC5LP) */
                
    #elif (PWMServoSharp_UseControl)
        PWMServoSharp_CONTROL &= PWMServoSharp_CTRL_CMPMODE1_MASK; /*Clear existing mode */
        PWMServoSharp_CONTROL |= comparemodemasked;
    #endif    /* (PWMServoSharp_UsingFixedFunction) */
}
#endif /* PWMServoSharp_CompareMode1SW */


#if (PWMServoSharp_CompareMode2SW)


/*******************************************************************************
* Function Name: PWMServoSharp_SetCompareMode2
********************************************************************************
* 
* Summary:
*  This function writes the Compare Mode for the pwm or pwm2 output
*
* Parameters:  
*  comparemode:  The new compare mode for the PWM output. Use the compare types
*                defined in the H file as input arguments.
*
* Return: 
*  void
*
*******************************************************************************/
void PWMServoSharp_SetCompareMode2(uint8 comparemode) 
{
    #if(PWMServoSharp_UsingFixedFunction)
        /* Do Nothing because there is no second Compare Mode Register in FF block */ 
    #elif (PWMServoSharp_UseControl)
        uint8 comparemodemasked = (comparemode << PWMServoSharp_CTRL_CMPMODE2_SHIFT) & 
                                             PWMServoSharp_CTRL_CMPMODE2_MASK;
        PWMServoSharp_CONTROL &= PWMServoSharp_CTRL_CMPMODE2_MASK; /*Clear existing mode */
        PWMServoSharp_CONTROL |= comparemodemasked;
    #endif /* (PWMServoSharp_UsingFixedFunction) */
}
#endif /*PWMServoSharp_CompareMode2SW */
#endif /* UseOneCompareMode */


#if (!PWMServoSharp_UsingFixedFunction)


/*******************************************************************************
* Function Name: PWMServoSharp_WriteCounter
********************************************************************************
* 
* Summary:
*  This function is used to change the counter value.
*
* Parameters:  
*  counter:  This value may be between 1 and (2^Resolution)-1.   
*
* Return: 
*  void
*
*******************************************************************************/
void PWMServoSharp_WriteCounter(uint16 counter) \
                                   
{
    CY_SET_REG16(PWMServoSharp_COUNTER_LSB_PTR, counter);
}

/*******************************************************************************
* Function Name: PWMServoSharp_ReadCounter
********************************************************************************
* 
* Summary:
*  This function returns the current value of the counter.  It doesn't matter
*  if the counter is enabled or running.
*
* Parameters:  
*  void  
*
* Return: 
*  The current value of the counter.
*
*******************************************************************************/
uint16 PWMServoSharp_ReadCounter(void) 
{
    /* Force capture by reading Accumulator */
    /* Must first do a software capture to be able to read the counter */
    /* It is up to the user code to make sure there isn't already captured data in the FIFO */
    CY_GET_REG8(PWMServoSharp_COUNTERCAP_LSB_PTR);
    
    /* Read the data from the FIFO (or capture register for Fixed Function)*/
    return (CY_GET_REG16(PWMServoSharp_CAPTURE_LSB_PTR));
}


#if (PWMServoSharp_UseStatus)


/*******************************************************************************
* Function Name: PWMServoSharp_ClearFIFO
********************************************************************************
* 
* Summary:
*  This function clears all capture data from the capture FIFO
*
* Parameters:  
*  void
*
* Return: 
*  void
*
*******************************************************************************/
void PWMServoSharp_ClearFIFO(void) 
{
    while(PWMServoSharp_ReadStatusRegister() & PWMServoSharp_STATUS_FIFONEMPTY)
        PWMServoSharp_ReadCapture();
}
#endif /* PWMServoSharp_UseStatus */
#endif /* !PWMServoSharp_UsingFixedFunction */


/*******************************************************************************
* Function Name: PWMServoSharp_WritePeriod
********************************************************************************
* 
* Summary:
*  This function is used to change the period of the counter.  The new period 
*  will be loaded the next time terminal count is detected.
*
* Parameters:  
*  period:  Period value. May be between 1 and (2^Resolution)-1.  A value of 0 
*           will result in the counter remaining at zero.
*
* Return: 
*  void
*
*******************************************************************************/
void PWMServoSharp_WritePeriod(uint16 period) 
{
    #if(PWMServoSharp_UsingFixedFunction)
        CY_SET_REG16(PWMServoSharp_PERIOD_LSB_PTR, (uint16)period);
    #else
        CY_SET_REG16(PWMServoSharp_PERIOD_LSB_PTR, period);
    #endif /* (PWMServoSharp_UsingFixedFunction) */
}


#if (PWMServoSharp_UseOneCompareMode)


/*******************************************************************************
* Function Name: PWMServoSharp_WriteCompare
********************************************************************************
* 
* Summary:
*  This funtion is used to change the compare1 value when the PWM is in Dither
*  mode. The compare output will reflect the new value on the next UDB clock. 
*  The compare output will be driven high when the present counter value is 
*  compared to the compare value based on the compare mode defined in 
*  Dither Mode.
*
* Parameters:  
*  compare:  New compare value.  
*
* Return: 
*  void
*
* Side Effects:
*  This function is only available if the PWM mode parameter is set to
*  Dither Mode, Center Aligned Mode or One Output Mode
*
*******************************************************************************/
void PWMServoSharp_WriteCompare(uint16 compare) \
                                   
{
   CY_SET_REG16(PWMServoSharp_COMPARE1_LSB_PTR, compare);
   #if (PWMServoSharp_PWMMode == PWMServoSharp__B_PWM__DITHER)
        CY_SET_REG16(PWMServoSharp_COMPARE2_LSB_PTR, compare+1);
   #endif /* (PWMServoSharp_PWMMode == PWMServoSharp__B_PWM__DITHER) */
}


#else


/*******************************************************************************
* Function Name: PWMServoSharp_WriteCompare1
********************************************************************************
* 
* Summary:
*  This funtion is used to change the compare1 value.  The compare output will 
*  reflect the new value on the next UDB clock.  The compare output will be 
*  driven high when the present counter value is less than or less than or 
*  equal to the compare register, depending on the mode.
*
* Parameters:  
*  compare:  New compare value.  
*
* Return: 
*  void
*
*******************************************************************************/
void PWMServoSharp_WriteCompare1(uint16 compare) \
                                    
{
    #if(PWMServoSharp_UsingFixedFunction)
        CY_SET_REG16(PWMServoSharp_COMPARE1_LSB_PTR, (uint16)compare);
    #else
        CY_SET_REG16(PWMServoSharp_COMPARE1_LSB_PTR, compare);
    #endif /* (PWMServoSharp_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: PWMServoSharp_WriteCompare2
********************************************************************************
* 
* Summary:
*  This funtion is used to change the compare value, for compare1 output.  
*  The compare output will reflect the new value on the next UDB clock.  
*  The compare output will be driven high when the present counter value is 
*  less than or less than or equal to the compare register, depending on the 
*  mode.
*
* Parameters:  
*  compare:  New compare value.  
*
* Return: 
*  void
*
*******************************************************************************/
void PWMServoSharp_WriteCompare2(uint16 compare) \
                                    
{
    #if(PWMServoSharp_UsingFixedFunction)
        CY_SET_REG16(PWMServoSharp_COMPARE2_LSB_PTR, compare);
    #else
        CY_SET_REG16(PWMServoSharp_COMPARE2_LSB_PTR, compare);
    #endif /* (PWMServoSharp_UsingFixedFunction) */
}
#endif /* UseOneCompareMode */


#if (PWMServoSharp_DeadBandUsed)


/*******************************************************************************
* Function Name: PWMServoSharp_WriteDeadTime
********************************************************************************
* 
* Summary:
*  This function writes the dead-band counts to the corresponding register
*
* Parameters:  
*  deadtime:  Number of counts for dead time 
*
* Return: 
*  void
*
*******************************************************************************/
void PWMServoSharp_WriteDeadTime(uint8 deadtime) 
{
    /* If using the Dead Band 1-255 mode then just write the register */
    #if(!PWMServoSharp_DeadBand2_4)
        CY_SET_REG8(PWMServoSharp_DEADBAND_COUNT_PTR, deadtime);
    #else
        /* Otherwise the data has to be masked and offset */        
        /* Clear existing data */
        PWMServoSharp_DEADBAND_COUNT &= ~PWMServoSharp_DEADBAND_COUNT_MASK; 
            /* Set new dead time */
        PWMServoSharp_DEADBAND_COUNT |= (deadtime << PWMServoSharp_DEADBAND_COUNT_SHIFT) & 
                                            PWMServoSharp_DEADBAND_COUNT_MASK; 
    #endif /* (!PWMServoSharp_DeadBand2_4) */
}


/*******************************************************************************
* Function Name: PWMServoSharp_ReadDeadTime
********************************************************************************
* 
* Summary:
*  This function reads the dead-band counts from the corresponding register
*
* Parameters:  
*  void
*
* Return: 
*  Dead Band Counts
*
*******************************************************************************/
uint8 PWMServoSharp_ReadDeadTime(void) 
{
    /* If using the Dead Band 1-255 mode then just read the register */
    #if(!PWMServoSharp_DeadBand2_4)
        return (CY_GET_REG8(PWMServoSharp_DEADBAND_COUNT_PTR));
    #else
        /* Otherwise the data has to be masked and offset */
        return ((PWMServoSharp_DEADBAND_COUNT & PWMServoSharp_DEADBAND_COUNT_MASK) >> 
                 PWMServoSharp_DEADBAND_COUNT_SHIFT);
    #endif /* (!PWMServoSharp_DeadBand2_4) */
}
#endif /* DeadBandUsed */


/* [] END OF FILE */
