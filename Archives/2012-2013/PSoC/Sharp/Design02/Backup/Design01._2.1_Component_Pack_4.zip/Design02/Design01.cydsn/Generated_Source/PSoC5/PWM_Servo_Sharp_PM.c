/*******************************************************************************
* File Name: PWM_Servo_Sharp_PM.c
* Version 2.20
*
* Description:
*  This file provides the power management source code to API for the
*  PWM.
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/
#include "cytypes.h"
#include "PWM_Servo_Sharp.h"

static PWM_Servo_Sharp_backupStruct PWM_Servo_Sharp_backup;


/*******************************************************************************
* Function Name: PWM_Servo_Sharp_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration of the component.
*  
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  PWM_Servo_Sharp_backup:  Variables of this global structure are modified to 
*  store the values of non retention configuration registers when Sleep() API is 
*  called.
*
*******************************************************************************/
void PWM_Servo_Sharp_SaveConfig(void) 
{
    
    #if(!PWM_Servo_Sharp_UsingFixedFunction)
        #if (CY_PSOC5A)
            PWM_Servo_Sharp_backup.PWMUdb = PWM_Servo_Sharp_ReadCounter();
            PWM_Servo_Sharp_backup.PWMPeriod = PWM_Servo_Sharp_ReadPeriod();
            #if (PWM_Servo_Sharp_UseStatus)
                PWM_Servo_Sharp_backup.InterruptMaskValue = PWM_Servo_Sharp_STATUS_MASK;
            #endif /* (PWM_Servo_Sharp_UseStatus) */
            
            #if(PWM_Servo_Sharp_UseOneCompareMode)
                PWM_Servo_Sharp_backup.PWMCompareValue = PWM_Servo_Sharp_ReadCompare();
            #else
                PWM_Servo_Sharp_backup.PWMCompareValue1 = PWM_Servo_Sharp_ReadCompare1();
                PWM_Servo_Sharp_backup.PWMCompareValue2 = PWM_Servo_Sharp_ReadCompare2();
            #endif /* (PWM_Servo_Sharp_UseOneCompareMode) */
            
           #if(PWM_Servo_Sharp_DeadBandUsed)
                PWM_Servo_Sharp_backup.PWMdeadBandValue = PWM_Servo_Sharp_ReadDeadTime();
            #endif /* (PWM_Servo_Sharp_DeadBandUsed) */
          
            #if ( PWM_Servo_Sharp_KillModeMinTime)
                PWM_Servo_Sharp_backup.PWMKillCounterPeriod = PWM_Servo_Sharp_ReadKillTime();
            #endif /* ( PWM_Servo_Sharp_KillModeMinTime) */
        #endif /* (CY_PSOC5A) */
        
        #if (CY_PSOC3 || CY_PSOC5LP)
            #if(!PWM_Servo_Sharp_PWMModeIsCenterAligned)
                PWM_Servo_Sharp_backup.PWMPeriod = PWM_Servo_Sharp_ReadPeriod();
            #endif /* (!PWM_Servo_Sharp_PWMModeIsCenterAligned) */
            PWM_Servo_Sharp_backup.PWMUdb = PWM_Servo_Sharp_ReadCounter();
            #if (PWM_Servo_Sharp_UseStatus)
                PWM_Servo_Sharp_backup.InterruptMaskValue = PWM_Servo_Sharp_STATUS_MASK;
            #endif /* (PWM_Servo_Sharp_UseStatus) */
            
            #if(PWM_Servo_Sharp_DeadBandMode == PWM_Servo_Sharp__B_PWM__DBM_256_CLOCKS || \
                PWM_Servo_Sharp_DeadBandMode == PWM_Servo_Sharp__B_PWM__DBM_2_4_CLOCKS)
                PWM_Servo_Sharp_backup.PWMdeadBandValue = PWM_Servo_Sharp_ReadDeadTime();
            #endif /*  deadband count is either 2-4 clocks or 256 clocks */
            
            #if(PWM_Servo_Sharp_KillModeMinTime)
                 PWM_Servo_Sharp_backup.PWMKillCounterPeriod = PWM_Servo_Sharp_ReadKillTime();
            #endif /* (PWM_Servo_Sharp_KillModeMinTime) */
        #endif /* (CY_PSOC3 || CY_PSOC5LP) */
        
        #if(PWM_Servo_Sharp_UseControl)
            PWM_Servo_Sharp_backup.PWMControlRegister = PWM_Servo_Sharp_ReadControlRegister();
        #endif /* (PWM_Servo_Sharp_UseControl) */
    #endif  /* (!PWM_Servo_Sharp_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: PWM_Servo_Sharp_RestoreConfig
********************************************************************************
* 
* Summary:
*  Restores the current user configuration of the component.
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  PWM_Servo_Sharp_backup:  Variables of this global structure are used to  
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void PWM_Servo_Sharp_RestoreConfig(void) 
{
        #if(!PWM_Servo_Sharp_UsingFixedFunction)
            #if (CY_PSOC5A)
                /* Interrupt State Backup for Critical Region*/
                uint8 PWM_Servo_Sharp_interruptState;
                /* Enter Critical Region*/
                PWM_Servo_Sharp_interruptState = CyEnterCriticalSection();
                #if (PWM_Servo_Sharp_UseStatus)
                    /* Use the interrupt output of the status register for IRQ output */
                    PWM_Servo_Sharp_STATUS_AUX_CTRL |= PWM_Servo_Sharp_STATUS_ACTL_INT_EN_MASK;
                    
                    PWM_Servo_Sharp_STATUS_MASK = PWM_Servo_Sharp_backup.InterruptMaskValue;
                #endif /* (PWM_Servo_Sharp_UseStatus) */
                
                #if (PWM_Servo_Sharp_Resolution == 8)
                    /* Set FIFO 0 to 1 byte register for period*/
                    PWM_Servo_Sharp_AUX_CONTROLDP0 |= (PWM_Servo_Sharp_AUX_CTRL_FIFO0_CLR);
                #else /* (PWM_Servo_Sharp_Resolution == 16)*/
                    /* Set FIFO 0 to 1 byte register for period */
                    PWM_Servo_Sharp_AUX_CONTROLDP0 |= (PWM_Servo_Sharp_AUX_CTRL_FIFO0_CLR);
                    PWM_Servo_Sharp_AUX_CONTROLDP1 |= (PWM_Servo_Sharp_AUX_CTRL_FIFO0_CLR);
                #endif /* (PWM_Servo_Sharp_Resolution == 8) */
                /* Exit Critical Region*/
                CyExitCriticalSection(PWM_Servo_Sharp_interruptState);
                
                PWM_Servo_Sharp_WriteCounter(PWM_Servo_Sharp_backup.PWMUdb);
                PWM_Servo_Sharp_WritePeriod(PWM_Servo_Sharp_backup.PWMPeriod);
                
                #if(PWM_Servo_Sharp_UseOneCompareMode)
                    PWM_Servo_Sharp_WriteCompare(PWM_Servo_Sharp_backup.PWMCompareValue);
                #else
                    PWM_Servo_Sharp_WriteCompare1(PWM_Servo_Sharp_backup.PWMCompareValue1);
                    PWM_Servo_Sharp_WriteCompare2(PWM_Servo_Sharp_backup.PWMCompareValue2);
                #endif /* (PWM_Servo_Sharp_UseOneCompareMode) */
                
               #if(PWM_Servo_Sharp_DeadBandMode == PWM_Servo_Sharp__B_PWM__DBM_256_CLOCKS || \
                   PWM_Servo_Sharp_DeadBandMode == PWM_Servo_Sharp__B_PWM__DBM_2_4_CLOCKS)
                    PWM_Servo_Sharp_WriteDeadTime(PWM_Servo_Sharp_backup.PWMdeadBandValue);
                #endif /* deadband count is either 2-4 clocks or 256 clocks */
            
                #if ( PWM_Servo_Sharp_KillModeMinTime)
                    PWM_Servo_Sharp_WriteKillTime(PWM_Servo_Sharp_backup.PWMKillCounterPeriod);
                #endif /* ( PWM_Servo_Sharp_KillModeMinTime) */
            #endif /* (CY_PSOC5A) */
            
            #if (CY_PSOC3 || CY_PSOC5LP)
                #if(!PWM_Servo_Sharp_PWMModeIsCenterAligned)
                    PWM_Servo_Sharp_WritePeriod(PWM_Servo_Sharp_backup.PWMPeriod);
                #endif /* (!PWM_Servo_Sharp_PWMModeIsCenterAligned) */
                PWM_Servo_Sharp_WriteCounter(PWM_Servo_Sharp_backup.PWMUdb);
                #if (PWM_Servo_Sharp_UseStatus)
                    PWM_Servo_Sharp_STATUS_MASK = PWM_Servo_Sharp_backup.InterruptMaskValue;
                #endif /* (PWM_Servo_Sharp_UseStatus) */
                
                #if(PWM_Servo_Sharp_DeadBandMode == PWM_Servo_Sharp__B_PWM__DBM_256_CLOCKS || \
                    PWM_Servo_Sharp_DeadBandMode == PWM_Servo_Sharp__B_PWM__DBM_2_4_CLOCKS)
                    PWM_Servo_Sharp_WriteDeadTime(PWM_Servo_Sharp_backup.PWMdeadBandValue);
                #endif /* deadband count is either 2-4 clocks or 256 clocks */
                
                #if(PWM_Servo_Sharp_KillModeMinTime)
                    PWM_Servo_Sharp_WriteKillTime(PWM_Servo_Sharp_backup.PWMKillCounterPeriod);
                #endif /* (PWM_Servo_Sharp_KillModeMinTime) */
            #endif /* (CY_PSOC3 || CY_PSOC5LP) */
            
            #if(PWM_Servo_Sharp_UseControl)
                PWM_Servo_Sharp_WriteControlRegister(PWM_Servo_Sharp_backup.PWMControlRegister); 
            #endif /* (PWM_Servo_Sharp_UseControl) */
        #endif  /* (!PWM_Servo_Sharp_UsingFixedFunction) */
    }


/*******************************************************************************
* Function Name: PWM_Servo_Sharp_Sleep
********************************************************************************
* 
* Summary:
*  Disables block's operation and saves the user configuration. Should be called 
*  just prior to entering sleep.
*  
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  PWM_Servo_Sharp_backup.PWMEnableState:  Is modified depending on the enable 
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void PWM_Servo_Sharp_Sleep(void) 
{
    #if(PWM_Servo_Sharp_UseControl)
        if(PWM_Servo_Sharp_CTRL_ENABLE == (PWM_Servo_Sharp_CONTROL & PWM_Servo_Sharp_CTRL_ENABLE))
        {
            /*Component is enabled */
            PWM_Servo_Sharp_backup.PWMEnableState = 1u;
        }
        else
        {
            /* Component is disabled */
            PWM_Servo_Sharp_backup.PWMEnableState = 0u;
        }
    #endif /* (PWM_Servo_Sharp_UseControl) */
    /* Stop component */
    PWM_Servo_Sharp_Stop();
    
    /* Save registers configuration */
    PWM_Servo_Sharp_SaveConfig();
}


/*******************************************************************************
* Function Name: PWM_Servo_Sharp_Wakeup
********************************************************************************
* 
* Summary:
*  Restores and enables the user configuration. Should be called just after 
*  awaking from sleep.
*  
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  PWM_Servo_Sharp_backup.pwmEnable:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void PWM_Servo_Sharp_Wakeup(void) 
{
     /* Restore registers values */
    PWM_Servo_Sharp_RestoreConfig();
    
    if(PWM_Servo_Sharp_backup.PWMEnableState != 0u)
    {
        /* Enable component's operation */
        PWM_Servo_Sharp_Enable();
    } /* Do nothing if component's block was disabled before */
    
}


/* [] END OF FILE */
