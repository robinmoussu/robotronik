/*******************************************************************************
* File Name: PWMServoSharp.h  
* Version 2.20
*
* Description:
*  Contains the prototypes and constants for the functions available to the 
*  PWM user module.
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#include "cytypes.h"
#include "cyfitter.h"
#include "CyLib.h" /* For CyEnterCriticalSection() and CyExitCriticalSection() functions */

#if !defined(CY_PWM_PWMServoSharp_H)
#define CY_PWM_PWMServoSharp_H


/***************************************
* Conditional Compilation Parameters
***************************************/
#define PWMServoSharp_Resolution 16u
#define PWMServoSharp_UsingFixedFunction 0u
#define PWMServoSharp_DeadBandMode 0u
#define PWMServoSharp_KillModeMinTime 0u
#define PWMServoSharp_KillMode 0u
#define PWMServoSharp_PWMMode 0u
#define PWMServoSharp_PWMModeIsCenterAligned 0u
#define PWMServoSharp_DeadBandUsed 0u
#define PWMServoSharp_DeadBand2_4 0u
#if !defined(PWMServoSharp_PWMUDB_sSTSReg_stsreg__REMOVED)
    #define PWMServoSharp_UseStatus 0u
#else
    #define PWMServoSharp_UseStatus 0u
#endif /* !defined(PWMServoSharp_PWMUDB_sSTSReg_stsreg__REMOVED) */
#if !defined(PWMServoSharp_PWMUDB_sCTRLReg_ctrlreg__REMOVED)
    #define PWMServoSharp_UseControl 1u
#else
    #define PWMServoSharp_UseControl 0u
#endif /* !defined(PWMServoSharp_PWMUDB_sCTRLReg_ctrlreg__REMOVED) */
#define PWMServoSharp_UseOneCompareMode 1u
#define PWMServoSharp_MinimumKillTime 1u
#define PWMServoSharp_EnableMode 0u

#define PWMServoSharp_CompareMode1SW 0u
#define PWMServoSharp_CompareMode2SW 0u

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component PWM_v2_20 requires cy_boot v3.0 or later
#endif /* (CY_ PSOC5LP) */

/* Use Kill Mode Enumerated Types */
#define PWMServoSharp__B_PWM__DISABLED 0
#define PWMServoSharp__B_PWM__ASYNCHRONOUS 1
#define PWMServoSharp__B_PWM__SINGLECYCLE 2
#define PWMServoSharp__B_PWM__LATCHED 3
#define PWMServoSharp__B_PWM__MINTIME 4


/* Use Dead Band Mode Enumerated Types */
#define PWMServoSharp__B_PWM__DBMDISABLED 0
#define PWMServoSharp__B_PWM__DBM_2_4_CLOCKS 1
#define PWMServoSharp__B_PWM__DBM_256_CLOCKS 2


/* Used PWM Mode Enumerated Types */
#define PWMServoSharp__B_PWM__ONE_OUTPUT 0
#define PWMServoSharp__B_PWM__TWO_OUTPUTS 1
#define PWMServoSharp__B_PWM__DUAL_EDGE 2
#define PWMServoSharp__B_PWM__CENTER_ALIGN 3
#define PWMServoSharp__B_PWM__DITHER 5
#define PWMServoSharp__B_PWM__HARDWARESELECT 4


/* Used PWM Compare Mode Enumerated Types */
#define PWMServoSharp__B_PWM__LESS_THAN 1
#define PWMServoSharp__B_PWM__LESS_THAN_OR_EQUAL 2
#define PWMServoSharp__B_PWM__GREATER_THAN 3
#define PWMServoSharp__B_PWM__GREATER_THAN_OR_EQUAL_TO 4
#define PWMServoSharp__B_PWM__EQUAL 0
#define PWMServoSharp__B_PWM__FIRMWARE 5



/***************************************
* Data Struct Definition
***************************************/


/**************************************************************************
 * Sleep Wakeup Backup structure for PWM Component
 *************************************************************************/
typedef struct PWMServoSharp_backupStruct
{
    
    uint8 PWMEnableState;
       
    #if(!PWMServoSharp_UsingFixedFunction)
        #if (CY_PSOC5A)
            uint16 PWMUdb;               /* PWM Current Counter value  */
            uint16 PWMPeriod;            /* PWM Current Period value   */
            #if (PWMServoSharp_UseStatus)
                uint8 InterruptMaskValue;   /* PWM Current Interrupt Mask */
            #endif /* (PWMServoSharp_UseStatus) */
            #if(PWMServoSharp_UseOneCompareMode)
                uint16 PWMCompareValue;     /* PWM Current Compare value */
            #else
                uint16 PWMCompareValue1;     /* PWM Current Compare value1 */
                uint16 PWMCompareValue2;     /* PWM Current Compare value2 */
            #endif /* (PWMServoSharp_UseOneCompareMode) */
            
            /* Backup for Deadband parameters */
            #if(PWMServoSharp_DeadBandMode == PWMServoSharp__B_PWM__DBM_256_CLOCKS || \
                PWMServoSharp_DeadBandMode == PWMServoSharp__B_PWM__DBM_2_4_CLOCKS)
                uint8 PWMdeadBandValue; /* Dead Band Counter Current Value */
            #endif /* deadband count is either 2-4 clocks or 256 clocks */
            
            /* Backup Kill Mode Counter*/
            #if(PWMServoSharp_KillModeMinTime)
                uint8 PWMKillCounterPeriod; /* Kill Mode period value */
            #endif /* (PWMServoSharp_KillModeMinTime) */
            
        #endif /* (CY_PSOC5A) */
        
        #if (CY_PSOC3 || CY_PSOC5LP)
            uint16 PWMUdb;               /* PWM Current Counter value  */
            #if(!PWMServoSharp_PWMModeIsCenterAligned)
                uint16 PWMPeriod;
            #endif /* (!PWMServoSharp_PWMModeIsCenterAligned) */
            #if (PWMServoSharp_UseStatus)
                uint8 InterruptMaskValue;   /* PWM Current Interrupt Mask */
            #endif /* (PWMServoSharp_UseStatus) */
            
            /* Backup for Deadband parameters */
            #if(PWMServoSharp_DeadBandMode == PWMServoSharp__B_PWM__DBM_256_CLOCKS || \
                PWMServoSharp_DeadBandMode == PWMServoSharp__B_PWM__DBM_2_4_CLOCKS)
                uint8 PWMdeadBandValue; /* Dead Band Counter Current Value */
            #endif /* deadband count is either 2-4 clocks or 256 clocks */
            
            /* Backup Kill Mode Counter*/
            #if(PWMServoSharp_KillModeMinTime)
                uint8 PWMKillCounterPeriod; /* Kill Mode period value */
            #endif /* (PWMServoSharp_KillModeMinTime) */
        #endif /* (CY_PSOC3 || CY_PSOC5LP) */
        
        
        /* Backup control register */
        #if(PWMServoSharp_UseControl)
            uint8 PWMControlRegister; /* PWM Control Register value */
        #endif /* (PWMServoSharp_UseControl) */
        
    #endif /* (!PWMServoSharp_UsingFixedFunction) */
   
}PWMServoSharp_backupStruct;


/***************************************
*        Function Prototypes
 **************************************/
 
void    PWMServoSharp_Start(void) ;
void    PWMServoSharp_Stop(void) ;
#if (PWMServoSharp_UseStatus || PWMServoSharp_UsingFixedFunction)
    #define PWMServoSharp_SetInterruptMode(interruptMode) CY_SET_REG8(PWMServoSharp_STATUS_MASK_PTR, interruptMode)
    #define PWMServoSharp_ReadStatusRegister() CY_GET_REG8(PWMServoSharp_STATUS_PTR)
#endif /* (PWMServoSharp_UseStatus || PWMServoSharp_UsingFixedFunction) */
#define PWMServoSharp_GetInterruptSource() PWMServoSharp_ReadStatusRegister()
#if (PWMServoSharp_UseControl)
    #define PWMServoSharp_ReadControlRegister() CY_GET_REG8(PWMServoSharp_CONTROL_PTR) 
    #define PWMServoSharp_WriteControlRegister(control) CY_SET_REG8(PWMServoSharp_CONTROL_PTR, control)
#endif /* (PWMServoSharp_UseControl) */
#if (PWMServoSharp_UseOneCompareMode)
   #if (PWMServoSharp_CompareMode1SW)
       void    PWMServoSharp_SetCompareMode(uint8 comparemode) ;
   #endif /* (PWMServoSharp_CompareMode1SW) */
#else
    #if (PWMServoSharp_CompareMode1SW)
        void    PWMServoSharp_SetCompareMode1(uint8 comparemode) \
                                                ;
    #endif /* (PWMServoSharp_CompareMode1SW) */
    #if (PWMServoSharp_CompareMode2SW)
        void    PWMServoSharp_SetCompareMode2(uint8 comparemode) \
                                                ;
    #endif /* (PWMServoSharp_CompareMode2SW) */
#endif /* (PWMServoSharp_UseOneCompareMode) */

#if (!PWMServoSharp_UsingFixedFunction)
    uint16   PWMServoSharp_ReadCounter(void) ;
    #define PWMServoSharp_ReadCapture() CY_GET_REG16(PWMServoSharp_CAPTURE_LSB_PTR)
    #if (PWMServoSharp_UseStatus)
        void PWMServoSharp_ClearFIFO(void) ;
    #endif /* (PWMServoSharp_UseStatus) */

    void    PWMServoSharp_WriteCounter(uint16 counter) \
                                       ;
#endif /* (!PWMServoSharp_UsingFixedFunction) */

void    PWMServoSharp_WritePeriod(uint16 period) \
                                     ;
#define PWMServoSharp_ReadPeriod() CY_GET_REG16(PWMServoSharp_PERIOD_LSB_PTR) 
#if (PWMServoSharp_UseOneCompareMode)
    void    PWMServoSharp_WriteCompare(uint16 compare) \
                                          ;
    #define PWMServoSharp_ReadCompare() CY_GET_REG16(PWMServoSharp_COMPARE1_LSB_PTR) 
#else
    void    PWMServoSharp_WriteCompare1(uint16 compare) \
                                           ;
    #define PWMServoSharp_ReadCompare1() CY_GET_REG16(PWMServoSharp_COMPARE1_LSB_PTR) 
    void    PWMServoSharp_WriteCompare2(uint16 compare) \
                                           ;
    #define PWMServoSharp_ReadCompare2() CY_GET_REG16(PWMServoSharp_COMPARE2_LSB_PTR) 
#endif /* (PWMServoSharp_UseOneCompareMode) */


#if (PWMServoSharp_DeadBandUsed)
    void    PWMServoSharp_WriteDeadTime(uint8 deadtime) ;
    uint8   PWMServoSharp_ReadDeadTime(void) ;
#endif /* (PWMServoSharp_DeadBandUsed) */

#if ( PWMServoSharp_KillModeMinTime)
    #define PWMServoSharp_WriteKillTime(killtime) CY_SET_REG8(PWMServoSharp_KILLMODEMINTIME_PTR, killtime) 
    #define PWMServoSharp_ReadKillTime() CY_GET_REG8(PWMServoSharp_KILLMODEMINTIME_PTR) 
#endif /* ( PWMServoSharp_KillModeMinTime) */

void PWMServoSharp_Init(void) ;
void PWMServoSharp_Enable(void) ;
void PWMServoSharp_Sleep(void) ;
void PWMServoSharp_Wakeup(void) ;
void PWMServoSharp_SaveConfig(void) ;
void PWMServoSharp_RestoreConfig(void) ;


/***************************************
*         Initialization Values
**************************************/
#define PWMServoSharp_INIT_PERIOD_VALUE        999u
#define PWMServoSharp_INIT_COMPARE_VALUE1      22u
#define PWMServoSharp_INIT_COMPARE_VALUE2      63u
#define PWMServoSharp_INIT_INTERRUPTS_MODE     ((0u << PWMServoSharp_STATUS_TC_INT_EN_MASK_SHIFT) | \
                                                  (0 << PWMServoSharp_STATUS_CMP2_INT_EN_MASK_SHIFT) | \
                                                  (0 << PWMServoSharp_STATUS_CMP1_INT_EN_MASK_SHIFT ) | \
                                                  (0 << PWMServoSharp_STATUS_KILL_INT_EN_MASK_SHIFT ))
#define PWMServoSharp_DEFAULT_COMPARE2_MODE    (1u << PWMServoSharp_CTRL_CMPMODE2_SHIFT)
#define PWMServoSharp_DEFAULT_COMPARE1_MODE    (1u << PWMServoSharp_CTRL_CMPMODE1_SHIFT)
#define PWMServoSharp_INIT_DEAD_TIME           1u


/********************************
*         Registers
******************************** */

#if (PWMServoSharp_UsingFixedFunction)
   #define PWMServoSharp_PERIOD_LSB          (*(reg16 *) PWMServoSharp_PWMHW__PER0)
   #define PWMServoSharp_PERIOD_LSB_PTR      ( (reg16 *) PWMServoSharp_PWMHW__PER0)
   #define PWMServoSharp_COMPARE1_LSB        (*(reg16 *) PWMServoSharp_PWMHW__CNT_CMP0)
   #define PWMServoSharp_COMPARE1_LSB_PTR    ( (reg16 *) PWMServoSharp_PWMHW__CNT_CMP0)
   #define PWMServoSharp_COMPARE2_LSB        0x00u
   #define PWMServoSharp_COMPARE2_LSB_PTR    0x00u
   #define PWMServoSharp_COUNTER_LSB         (*(reg16 *) PWMServoSharp_PWMHW__CNT_CMP0)
   #define PWMServoSharp_COUNTER_LSB_PTR     ( (reg16 *) PWMServoSharp_PWMHW__CNT_CMP0)
   #define PWMServoSharp_CAPTURE_LSB         (*(reg16 *) PWMServoSharp_PWMHW__CAP0)
   #define PWMServoSharp_CAPTURE_LSB_PTR     ( (reg16 *) PWMServoSharp_PWMHW__CAP0)
   #define PWMServoSharp_RT1                 (*(reg8 *)  PWMServoSharp_PWMHW__RT1)
   #define PWMServoSharp_RT1_PTR             ( (reg8 *)  PWMServoSharp_PWMHW__RT1)
      
#else
   #if(PWMServoSharp_PWMModeIsCenterAligned)
       #define PWMServoSharp_PERIOD_LSB      (*(reg16 *) PWMServoSharp_PWMUDB_sP16_pwmdp_u0__D1_REG)
       #define PWMServoSharp_PERIOD_LSB_PTR   ((reg16 *) PWMServoSharp_PWMUDB_sP16_pwmdp_u0__D1_REG)
   #else
       #define PWMServoSharp_PERIOD_LSB      (*(reg16 *) PWMServoSharp_PWMUDB_sP16_pwmdp_u0__F0_REG)
       #define PWMServoSharp_PERIOD_LSB_PTR   ((reg16 *) PWMServoSharp_PWMUDB_sP16_pwmdp_u0__F0_REG)
   #endif /* (PWMServoSharp_PWMModeIsCenterAligned) */
   #define PWMServoSharp_COMPARE1_LSB    (*(reg16 *) PWMServoSharp_PWMUDB_sP16_pwmdp_u0__D0_REG)
   #define PWMServoSharp_COMPARE1_LSB_PTR ((reg16 *) PWMServoSharp_PWMUDB_sP16_pwmdp_u0__D0_REG)
   #define PWMServoSharp_COMPARE2_LSB    (*(reg16 *) PWMServoSharp_PWMUDB_sP16_pwmdp_u0__D1_REG)
   #define PWMServoSharp_COMPARE2_LSB_PTR ((reg16 *) PWMServoSharp_PWMUDB_sP16_pwmdp_u0__D1_REG)
   #define PWMServoSharp_COUNTERCAP_LSB   *(reg16 *) PWMServoSharp_PWMUDB_sP16_pwmdp_u0__A1_REG)
   #define PWMServoSharp_COUNTERCAP_LSB_PTR ((reg16 *) PWMServoSharp_PWMUDB_sP16_pwmdp_u0__A1_REG)
   #define PWMServoSharp_COUNTER_LSB     (*(reg16 *) PWMServoSharp_PWMUDB_sP16_pwmdp_u0__A0_REG)
   #define PWMServoSharp_COUNTER_LSB_PTR  ((reg16 *) PWMServoSharp_PWMUDB_sP16_pwmdp_u0__A0_REG)
   #define PWMServoSharp_CAPTURE_LSB     (*(reg16 *) PWMServoSharp_PWMUDB_sP16_pwmdp_u0__F1_REG)
   #define PWMServoSharp_CAPTURE_LSB_PTR  ((reg16 *) PWMServoSharp_PWMUDB_sP16_pwmdp_u0__F1_REG)
   #define PWMServoSharp_AUX_CONTROLDP0      (*(reg8 *) PWMServoSharp_PWMUDB_sP16_pwmdp_u0__DP_AUX_CTL_REG)
   #define PWMServoSharp_AUX_CONTROLDP0_PTR  ((reg8 *) PWMServoSharp_PWMUDB_sP16_pwmdp_u0__DP_AUX_CTL_REG)
   #if (PWMServoSharp_Resolution == 16)
       #define PWMServoSharp_AUX_CONTROLDP1    (*(reg8 *) PWMServoSharp_PWMUDB_sP16_pwmdp_u1__DP_AUX_CTL_REG)
       #define PWMServoSharp_AUX_CONTROLDP1_PTR  ((reg8 *) PWMServoSharp_PWMUDB_sP16_pwmdp_u1__DP_AUX_CTL_REG)
   #endif /* (PWMServoSharp_Resolution == 16) */
#endif /* (PWMServoSharp_UsingFixedFunction) */
   
#if(PWMServoSharp_KillModeMinTime )
    #define PWMServoSharp_KILLMODEMINTIME      (*(reg8 *) PWMServoSharp_PWMUDB_sKM_killmodecounterdp_u0__D0_REG)
    #define PWMServoSharp_KILLMODEMINTIME_PTR   ((reg8 *) PWMServoSharp_PWMUDB_sKM_killmodecounterdp_u0__D0_REG)
    /* Fixed Function Block has no Kill Mode parameters because it is Asynchronous only */
#endif /* (PWMServoSharp_KillModeMinTime ) */

#if(PWMServoSharp_DeadBandMode == PWMServoSharp__B_PWM__DBM_256_CLOCKS)
    #define PWMServoSharp_DEADBAND_COUNT      (*(reg8 *) PWMServoSharp_PWMUDB_sDB255_deadbandcounterdp_u0__D0_REG)
    #define PWMServoSharp_DEADBAND_COUNT_PTR  ((reg8 *) PWMServoSharp_PWMUDB_sDB255_deadbandcounterdp_u0__D0_REG)
    #define PWMServoSharp_DEADBAND_LSB_PTR    ((reg8 *) PWMServoSharp_PWMUDB_sDB255_deadbandcounterdp_u0__A0_REG)
    #define PWMServoSharp_DEADBAND_LSB        (*(reg8 *) PWMServoSharp_PWMUDB_sDB255_deadbandcounterdp_u0__A0_REG)
#elif(PWMServoSharp_DeadBandMode == PWMServoSharp__B_PWM__DBM_2_4_CLOCKS)
    /* In Fixed Function Block these bits are in the control blocks control register */
    #if (PWMServoSharp_UsingFixedFunction)
        #define PWMServoSharp_DEADBAND_COUNT        (*(reg8 *) PWMServoSharp_PWMHW__CFG0) 
        #define PWMServoSharp_DEADBAND_COUNT_PTR     ((reg8 *) PWMServoSharp_PWMHW__CFG0)
        #define PWMServoSharp_DEADBAND_COUNT_MASK    (0x03u << PWMServoSharp_DEADBAND_COUNT_SHIFT)
        /* As defined by the Register Map as DEADBAND_PERIOD[1:0] in CFG0 */
        #define PWMServoSharp_DEADBAND_COUNT_SHIFT   0x06u  
    #else
        /* Lower two bits of the added control register define the count 1-3 */
        #define PWMServoSharp_DEADBAND_COUNT        (*(reg8 *) PWMServoSharp_PWMUDB_sDB3_AsyncCtl_dbctrlreg__CONTROL_REG)
        #define PWMServoSharp_DEADBAND_COUNT_PTR     ((reg8 *) PWMServoSharp_PWMUDB_sDB3_AsyncCtl_dbctrlreg__CONTROL_REG)
        #define PWMServoSharp_DEADBAND_COUNT_MASK    (0x03u << PWMServoSharp_DEADBAND_COUNT_SHIFT) 
        /* As defined by the verilog implementation of the Control Register */
        #define PWMServoSharp_DEADBAND_COUNT_SHIFT   0x00u 
    #endif /* (PWMServoSharp_UsingFixedFunction) */
#endif /* (PWMServoSharp_DeadBandMode == PWMServoSharp__B_PWM__DBM_256_CLOCKS) */



#if (PWMServoSharp_UsingFixedFunction)
    #define PWMServoSharp_STATUS                (*(reg8 *) PWMServoSharp_PWMHW__SR0)
    #define PWMServoSharp_STATUS_PTR            ((reg8 *) PWMServoSharp_PWMHW__SR0)
    #define PWMServoSharp_STATUS_MASK           (*(reg8 *) PWMServoSharp_PWMHW__SR0)
    #define PWMServoSharp_STATUS_MASK_PTR       ((reg8 *) PWMServoSharp_PWMHW__SR0)
    #define PWMServoSharp_CONTROL               (*(reg8 *) PWMServoSharp_PWMHW__CFG0)
    #define PWMServoSharp_CONTROL_PTR           ((reg8 *) PWMServoSharp_PWMHW__CFG0)    
    #define PWMServoSharp_CONTROL2              (*(reg8 *) PWMServoSharp_PWMHW__CFG1)    
    #if(CY_PSOC3 || CY_PSOC5LP)
        #define PWMServoSharp_CONTROL3              (*(reg8 *) PWMServoSharp_PWMHW__CFG2)
    #endif /* (CY_PSOC3 || CY_PSOC5LP) */
    #define PWMServoSharp_GLOBAL_ENABLE         (*(reg8 *) PWMServoSharp_PWMHW__PM_ACT_CFG)
    #define PWMServoSharp_GLOBAL_ENABLE_PTR       ( (reg8 *) PWMServoSharp_PWMHW__PM_ACT_CFG)
    #define PWMServoSharp_GLOBAL_STBY_ENABLE      (*(reg8 *) PWMServoSharp_PWMHW__PM_STBY_CFG)
    #define PWMServoSharp_GLOBAL_STBY_ENABLE_PTR  ( (reg8 *) PWMServoSharp_PWMHW__PM_STBY_CFG)
  
  
    /***********************************
    *          Constants
    ***********************************/

    /* Fixed Function Block Chosen */
    #define PWMServoSharp_BLOCK_EN_MASK          PWMServoSharp_PWMHW__PM_ACT_MSK
    #define PWMServoSharp_BLOCK_STBY_EN_MASK     PWMServoSharp_PWMHW__PM_STBY_MSK 
    /* Control Register definitions */
    #define PWMServoSharp_CTRL_ENABLE_SHIFT      0x00u
    
    #if(CY_PSOC5A)
        #define PWMServoSharp_CTRL_CMPMODE1_SHIFT    0x01u   /* As defined by Register map as MODE_CFG bits in CFG1*/
    #endif /* (CY_PSOC5A) */
    #if(CY_PSOC3 || CY_PSOC5LP)
        #define PWMServoSharp_CTRL_CMPMODE1_SHIFT    0x04u  /* As defined by Register map as MODE_CFG bits in CFG2*/
    #endif /* (CY_PSOC3 || CY_PSOC5LP) */
    
    #define PWMServoSharp_CTRL_DEAD_TIME_SHIFT   0x06u   /* As defined by Register map */
    /* Fixed Function Block Only CFG register bit definitions */
    #define PWMServoSharp_CFG0_MODE              0x02u   /*  Set to compare mode */
    /* #define PWMServoSharp_CFG0_ENABLE            0x01u */  /* Enable the block to run */
    #define PWMServoSharp_CFG0_DB                0x20u   /* As defined by Register map as DB bit in CFG0 */

    /* Control Register Bit Masks */
    #define PWMServoSharp_CTRL_ENABLE            (0x01u << PWMServoSharp_CTRL_ENABLE_SHIFT)
    #define PWMServoSharp_CTRL_RESET             (0x01u << PWMServoSharp_CTRL_RESET_SHIFT)
    #define PWMServoSharp_CTRL_CMPMODE2_MASK     (0x07u << PWMServoSharp_CTRL_CMPMODE2_SHIFT)
    #if(CY_PSOC5A)
        #define PWMServoSharp_CTRL_CMPMODE1_MASK     (0x07u << PWMServoSharp_CTRL_CMPMODE1_SHIFT)
    #endif /* (CY_PSOC5A) */
    #if(CY_PSOC3 || CY_PSOC5LP)
        #define PWMServoSharp_CTRL_CMPMODE1_MASK     (0x07u << PWMServoSharp_CTRL_CMPMODE1_SHIFT)
    #endif /* (CY_PSOC3 || CY_PSOC5LP) */
    
    /* Control2 Register Bit Masks */
    /* As defined in Register Map, Part of the TMRX_CFG1 register */
    #define PWMServoSharp_CTRL2_IRQ_SEL_SHIFT    0x00u       
    #define PWMServoSharp_CTRL2_IRQ_SEL          (0x01u << PWMServoSharp_CTRL2_IRQ_SEL_SHIFT)  
    
    /* Status Register Bit Locations */
    #define PWMServoSharp_STATUS_TC_SHIFT            0x07u   /* As defined by Register map as TC in SR0 */
    #define PWMServoSharp_STATUS_CMP1_SHIFT          0x06u   /* As defined by the Register map as CAP_CMP in SR0 */
    
    /* Status Register Interrupt Enable Bit Locations */
    #define PWMServoSharp_STATUS_KILL_INT_EN_MASK_SHIFT          (0x00u)    
    #define PWMServoSharp_STATUS_TC_INT_EN_MASK_SHIFT            (PWMServoSharp_STATUS_TC_SHIFT - 4)
    #define PWMServoSharp_STATUS_CMP2_INT_EN_MASK_SHIFT          (0x00u)  
    #define PWMServoSharp_STATUS_CMP1_INT_EN_MASK_SHIFT          (PWMServoSharp_STATUS_CMP1_SHIFT - 4)
    
    /* Status Register Bit Masks */
    #define PWMServoSharp_STATUS_TC              (0x01u << PWMServoSharp_STATUS_TC_SHIFT)
    #define PWMServoSharp_STATUS_CMP1            (0x01u << PWMServoSharp_STATUS_CMP1_SHIFT)
    
    /* Status Register Interrupt Bit Masks*/
    #define PWMServoSharp_STATUS_TC_INT_EN_MASK              (PWMServoSharp_STATUS_TC >> 4)
    #define PWMServoSharp_STATUS_CMP1_INT_EN_MASK            (PWMServoSharp_STATUS_CMP1 >> 4)
    
    /*RT1 Synch Constants: Applicable for PSoC3 and PSoC5LP*/
    #define PWMServoSharp_RT1_SHIFT             0x04u
    #define PWMServoSharp_RT1_MASK              (0x03u << PWMServoSharp_RT1_SHIFT)/* Sync TC and CMP bit masks */
    #define PWMServoSharp_SYNC                  (0x03u << PWMServoSharp_RT1_SHIFT)
    #define PWMServoSharp_SYNCDSI_SHIFT         0x00u
    #define PWMServoSharp_SYNCDSI_MASK          (0x0Fu << PWMServoSharp_SYNCDSI_SHIFT) /* Sync all DSI inputs */
    #define PWMServoSharp_SYNCDSI_EN            (0x0Fu << PWMServoSharp_SYNCDSI_SHIFT) /* Sync all DSI inputs */
    

#else
    #define PWMServoSharp_STATUS                (*(reg8 *) PWMServoSharp_PWMUDB_sSTSReg_nrstSts_stsreg__STATUS_REG )
    #define PWMServoSharp_STATUS_PTR            ((reg8 *) PWMServoSharp_PWMUDB_sSTSReg_nrstSts_stsreg__STATUS_REG )
    #define PWMServoSharp_STATUS_MASK           (*(reg8 *) PWMServoSharp_PWMUDB_sSTSReg_nrstSts_stsreg__MASK_REG)
    #define PWMServoSharp_STATUS_MASK_PTR       ((reg8 *) PWMServoSharp_PWMUDB_sSTSReg_nrstSts_stsreg__MASK_REG)
    #define PWMServoSharp_STATUS_AUX_CTRL       (*(reg8 *) PWMServoSharp_PWMUDB_sSTSReg_nrstSts_stsreg__STATUS_AUX_CTL_REG)
    #define PWMServoSharp_CONTROL               (*(reg8 *) PWMServoSharp_PWMUDB_sCTRLReg_AsyncCtl_ctrlreg__CONTROL_REG)
    #define PWMServoSharp_CONTROL_PTR           ((reg8 *) PWMServoSharp_PWMUDB_sCTRLReg_AsyncCtl_ctrlreg__CONTROL_REG)
    
    
    /***********************************
    *          Constants
    ***********************************/

    /* Control Register definitions */
    #define PWMServoSharp_CTRL_ENABLE_SHIFT      0x07u
    #define PWMServoSharp_CTRL_RESET_SHIFT       0x06u
    #define PWMServoSharp_CTRL_CMPMODE2_SHIFT    0x03u
    #define PWMServoSharp_CTRL_CMPMODE1_SHIFT    0x00u
    #define PWMServoSharp_CTRL_DEAD_TIME_SHIFT   0x00u   /* No Shift Needed for UDB block */
    /* Control Register Bit Masks */
    #define PWMServoSharp_CTRL_ENABLE            (0x01u << PWMServoSharp_CTRL_ENABLE_SHIFT)
    #define PWMServoSharp_CTRL_RESET             (0x01u << PWMServoSharp_CTRL_RESET_SHIFT)
    #define PWMServoSharp_CTRL_CMPMODE2_MASK     (0x07u << PWMServoSharp_CTRL_CMPMODE2_SHIFT)
    #define PWMServoSharp_CTRL_CMPMODE1_MASK     (0x07u << PWMServoSharp_CTRL_CMPMODE1_SHIFT) 
    
    /* Status Register Bit Locations */
    #define PWMServoSharp_STATUS_KILL_SHIFT          0x05u
    #define PWMServoSharp_STATUS_FIFONEMPTY_SHIFT    0x04u
    #define PWMServoSharp_STATUS_FIFOFULL_SHIFT      0x03u  
    #define PWMServoSharp_STATUS_TC_SHIFT            0x02u
    #define PWMServoSharp_STATUS_CMP2_SHIFT          0x01u
    #define PWMServoSharp_STATUS_CMP1_SHIFT          0x00u
    /* Status Register Interrupt Enable Bit Locations - UDB Status Interrupt Mask match Status Bit Locations*/
    #define PWMServoSharp_STATUS_KILL_INT_EN_MASK_SHIFT          PWMServoSharp_STATUS_KILL_SHIFT          
    #define PWMServoSharp_STATUS_FIFONEMPTY_INT_EN_MASK_SHIFT    PWMServoSharp_STATUS_FIFONEMPTY_SHIFT    
    #define PWMServoSharp_STATUS_FIFOFULL_INT_EN_MASK_SHIFT      PWMServoSharp_STATUS_FIFOFULL_SHIFT        
    #define PWMServoSharp_STATUS_TC_INT_EN_MASK_SHIFT            PWMServoSharp_STATUS_TC_SHIFT            
    #define PWMServoSharp_STATUS_CMP2_INT_EN_MASK_SHIFT          PWMServoSharp_STATUS_CMP2_SHIFT          
    #define PWMServoSharp_STATUS_CMP1_INT_EN_MASK_SHIFT          PWMServoSharp_STATUS_CMP1_SHIFT   
    /* Status Register Bit Masks */
    #define PWMServoSharp_STATUS_KILL            (0x00u << PWMServoSharp_STATUS_KILL_SHIFT )
    #define PWMServoSharp_STATUS_FIFOFULL        (0x01u << PWMServoSharp_STATUS_FIFOFULL_SHIFT)
    #define PWMServoSharp_STATUS_FIFONEMPTY      (0x01u << PWMServoSharp_STATUS_FIFONEMPTY_SHIFT)
    #define PWMServoSharp_STATUS_TC              (0x01u << PWMServoSharp_STATUS_TC_SHIFT)
    #define PWMServoSharp_STATUS_CMP2            (0x01u << PWMServoSharp_STATUS_CMP2_SHIFT) 
    #define PWMServoSharp_STATUS_CMP1            (0x01u << PWMServoSharp_STATUS_CMP1_SHIFT)
    /* Status Register Interrupt Bit Masks  - UDB Status Interrupt Mask match Status Bit Locations */
    #define PWMServoSharp_STATUS_KILL_INT_EN_MASK            PWMServoSharp_STATUS_KILL
    #define PWMServoSharp_STATUS_FIFOFULL_INT_EN_MASK        PWMServoSharp_STATUS_FIFOFULL
    #define PWMServoSharp_STATUS_FIFONEMPTY_INT_EN_MASK      PWMServoSharp_STATUS_FIFONEMPTY
    #define PWMServoSharp_STATUS_TC_INT_EN_MASK              PWMServoSharp_STATUS_TC
    #define PWMServoSharp_STATUS_CMP2_INT_EN_MASK            PWMServoSharp_STATUS_CMP2
    #define PWMServoSharp_STATUS_CMP1_INT_EN_MASK            PWMServoSharp_STATUS_CMP1
                                                          
    /* Datapath Auxillary Control Register definitions */
    #define PWMServoSharp_AUX_CTRL_FIFO0_CLR     0x01u
    #define PWMServoSharp_AUX_CTRL_FIFO1_CLR     0x02u
    #define PWMServoSharp_AUX_CTRL_FIFO0_LVL     0x04u
    #define PWMServoSharp_AUX_CTRL_FIFO1_LVL     0x08u
    #define PWMServoSharp_STATUS_ACTL_INT_EN_MASK  0x10u /* As defined for the ACTL Register */
#endif /* PWMServoSharp_UsingFixedFunction */

#endif  /* CY_PWM_PWMServoSharp_H */


/* [] END OF FILE */
