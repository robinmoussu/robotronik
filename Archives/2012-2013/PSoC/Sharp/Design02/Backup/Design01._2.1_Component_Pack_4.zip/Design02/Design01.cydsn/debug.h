/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef DEBUG_H
#define DEBUG_H

#include <project.h>

void ledAfficheEntier(unsigned int n);
void testStackFault(unsigned int testCode);

#endif
//[] END OF FILE
