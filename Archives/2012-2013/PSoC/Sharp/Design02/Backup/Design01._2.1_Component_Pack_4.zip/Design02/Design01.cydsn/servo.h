/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef SERVO_H
#define SERVO_H
//Position du sharp par rapport au 0 de l'asser 1=>Avant 2=>Arrière
#define X_SHARP_1 10
#define Y_SHARP_1 20
#define A_SHARP_1 0
#define X_SHARP_2 10
#define Y_SHARP_2 20
#define A_SHARP_2 180

#define ANGLESERVO 90

#include "debug.h"


struct Calibre
{
	int volt;
	int milli;
};
typedef struct Calibre Calibre;

void moveServo(void);
int conversion(int entree);
void initTableau(Calibre *calibre);
void afficheLED(unsigned int result);

#endif

//[] END OF FILE
